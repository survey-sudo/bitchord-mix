export interface ExtractedAudioFeatures {
  bpm: number;
  camelotKey: string;
  musicalKey: string;
  durationSec: number;
  introEndSec: number;
  outroStartSec: number;
  vocalIntroDensity: number;
  vocalOutroDensity: number;
  energy: number;
  hasSilenceTail: boolean;
  waveformPeaks: number[];
}

const PITCH_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

// Krumhansl-Schmuckler Major and Minor key profiles
const MAJOR_PROFILE = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
const MINOR_PROFILE = [6.33, 2.68, 3.52, 5.38, 2.6, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];

// Mapping from Pitch Class (0=C .. 11=B) to Camelot B (Major) and A (Minor)
const MAJOR_TO_CAMELOT: Record<number, string> = {
  0: "8B",  // C Major
  1: "3B",  // Db Major
  2: "10B", // D Major
  3: "5B",  // Eb Major
  4: "12B", // E Major
  5: "7B",  // F Major
  6: "2B",  // F# Major
  7: "9B",  // G Major
  8: "4B",  // Ab Major
  9: "11B", // A Major
  10: "6B", // Bb Major
  11: "1B", // B Major
};

const MINOR_TO_CAMELOT: Record<number, string> = {
  0: "5A",  // C Minor
  1: "12A", // C# Minor
  2: "7A",  // D Minor
  3: "2A",  // Eb Minor
  4: "9A",  // E Minor
  5: "4A",  // F Minor
  6: "11A", // F# Minor
  7: "6A",  // G Minor
  8: "1A",  // G# Minor
  9: "8A",  // A Minor
  10: "3A", // Bb Minor
  11: "10A",// B Minor
};

export function computeWaveformPeaks(buffer: AudioBuffer, numBins = 140): number[] {
  const ch0 = buffer.getChannelData(0);
  const ch1 = buffer.numberOfChannels > 1 ? buffer.getChannelData(1) : ch0;
  const samplesPerBin = Math.max(1, Math.floor(ch0.length / numBins));
  const peaks: number[] = [];
  let maxPeak = 0.001;

  for (let i = 0; i < numBins; i++) {
    const start = i * samplesPerBin;
    const end = Math.min(ch0.length, start + samplesPerBin);
    const step = Math.max(1, Math.floor((end - start) / 64));
    let sumSq = 0;
    let count = 0;
    for (let j = start; j < end; j += step) {
      const mono = (ch0[j] + ch1[j]) * 0.5;
      sumSq += mono * mono;
      count++;
    }
    const rms = count > 0 ? Math.sqrt(sumSq / count) : 0;
    peaks.push(rms);
    if (rms > maxPeak) maxPeak = rms;
  }

  return peaks.map((p) => Number(Math.min(1, Math.max(0.06, p / maxPeak)).toFixed(3)));
}

function detectBpmFromMono(samples: Float32Array, sampleRate: number): number {
  // Analyze up to 32 seconds from the energetic middle section
  const maxWindowSamples = Math.min(samples.length, Math.floor(sampleRate * 32));
  const startOffset = Math.max(0, Math.floor((samples.length - maxWindowSamples) * 0.35));
  const frameSize = 1024;
  const hopSize = 512;
  const numFrames = Math.floor((maxWindowSamples - frameSize) / hopSize);
  if (numFrames < 32) return 120;

  const energies = new Float32Array(numFrames);
  for (let f = 0; f < numFrames; f++) {
    const base = startOffset + f * hopSize;
    let e = 0;
    for (let i = 0; i < frameSize; i += 2) {
      const s = samples[base + i];
      e += s * s;
    }
    energies[f] = Math.sqrt(e / (frameSize * 0.5));
  }

  // First-order positive onset flux
  const onset = new Float32Array(numFrames);
  for (let f = 1; f < numFrames; f++) {
    const diff = energies[f] - energies[f - 1];
    onset[f] = diff > 0 ? diff : 0;
  }

  const envRate = sampleRate / hopSize;
  let bestBpm = 122;
  let bestScore = -1;

  for (let bpm = 78; bpm <= 162; bpm += 0.5) {
    const lag = envRate * (60 / bpm);
    const intLag = Math.round(lag);
    if (intLag < 2 || intLag >= numFrames - 2) continue;

    let corr = 0;
    for (let i = 0; i < numFrames - intLag; i++) {
      corr += onset[i] * onset[i + intLag];
    }
    // Slight perceptual prior toward 95..138 BPM common groove fundamental
    const prior = bpm >= 92 && bpm <= 138 ? 1.06 : 1.0;
    const score = (corr / (numFrames - intLag)) * prior;
    if (score > bestScore) {
      bestScore = score;
      bestBpm = bpm;
    }
  }

  return Number(bestBpm.toFixed(1));
}

function detectKeyFromMono(
  samples: Float32Array,
  sampleRate: number
): { camelotKey: string; musicalKey: string } {
  const chroma = new Float64Array(12);
  // Sample 8 short windows across the middle of the track using Goertzel pitch-class energy
  const windowSize = 4096;
  const numWindows = 8;
  const usableStart = Math.floor(samples.length * 0.18);
  const usableSpan = Math.max(windowSize, Math.floor(samples.length * 0.64));

  for (let w = 0; w < numWindows; w++) {
    const offset = Math.min(
      Math.max(0, samples.length - windowSize),
      usableStart + Math.floor((w / numWindows) * (usableSpan - windowSize))
    );

    // Evaluate octaves 2, 3, 4 (approx 65 Hz to 500 Hz harmonic body)
    for (let pc = 0; pc < 12; pc++) {
      for (const octave of [2, 3, 4]) {
        const midi = 12 * (octave + 1) + pc;
        const freq = 440 * Math.pow(2, (midi - 69) / 12);
        const k = Math.round((windowSize * freq) / sampleRate);
        const omega = (2 * Math.PI * k) / windowSize;
        const coeff = 2 * Math.cos(omega);
        let q1 = 0;
        let q2 = 0;
        for (let i = 0; i < windowSize; i += 2) {
          // Hann-like weighting
          const s = samples[offset + i];
          const q0 = coeff * q1 - q2 + s;
          q2 = q1;
          q1 = q0;
        }
        const magSq = q1 * q1 + q2 * q2 - q1 * q2 * coeff;
        if (magSq > 0) {
          chroma[pc] += Math.sqrt(magSq);
        }
      }
    }
  }

  let bestCorr = -Infinity;
  let bestPc = 9; // A
  let bestIsMinor = true;

  for (let root = 0; root < 12; root++) {
    let majScore = 0;
    let minScore = 0;
    for (let i = 0; i < 12; i++) {
      const c = chroma[(root + i) % 12];
      majScore += c * MAJOR_PROFILE[i];
      minScore += c * MINOR_PROFILE[i];
    }
    if (majScore > bestCorr) {
      bestCorr = majScore;
      bestPc = root;
      bestIsMinor = false;
    }
    if (minScore > bestCorr) {
      bestCorr = minScore;
      bestPc = root;
      bestIsMinor = true;
    }
  }

  const camelotKey = bestIsMinor ? MINOR_TO_CAMELOT[bestPc] : MAJOR_TO_CAMELOT[bestPc];
  const musicalKey = `${PITCH_NAMES[bestPc]} ${bestIsMinor ? "Minor" : "Major"}`;
  return { camelotKey, musicalKey };
}

export function analyzeAudioBufferOnDevice(buffer: AudioBuffer): ExtractedAudioFeatures {
  const ch0 = buffer.getChannelData(0);
  const sampleRate = buffer.sampleRate;
  const durationSec = Number(buffer.duration.toFixed(2));
  const waveformPeaks = computeWaveformPeaks(buffer, 140);

  const bpm = detectBpmFromMono(ch0, sampleRate);
  const { camelotKey, musicalKey } = detectKeyFromMono(ch0, sampleRate);

  // Compute overall energy & check silence tail in final 8% of waveformPeaks
  const avgPeak =
    waveformPeaks.reduce((acc, v) => acc + v, 0) / Math.max(1, waveformPeaks.length);
  const tailSlice = waveformPeaks.slice(Math.floor(waveformPeaks.length * 0.9));
  const tailAvg =
    tailSlice.reduce((acc, v) => acc + v, 0) / Math.max(1, tailSlice.length);
  const hasSilenceTail = tailAvg < avgPeak * 0.24;

  // Estimate structural intro & outro sweet-spot boundaries snapped to 4-bar phrases
  const barSec = (60 / bpm) * 4;
  const introEndSec = Number(
    Math.min(durationSec * 0.25, Math.max(barSec * 2, Math.round((durationSec * 0.14) / barSec) * barSec)).toFixed(2)
  );

  // Walk backwards from end to find where energy begins dropping or 8 bars before end
  let outroRatio = 0.78;
  for (let i = waveformPeaks.length - 3; i > Math.floor(waveformPeaks.length * 0.62); i--) {
    if (waveformPeaks[i] > avgPeak * 0.68) {
      outroRatio = Math.max(0.68, Math.min(0.86, (i - 8) / waveformPeaks.length));
      break;
    }
  }
  const rawOutroSec = durationSec * outroRatio;
  const outroStartSec = Number(
    Math.max(
      durationSec * 0.55,
      Math.min(durationSec - Math.max(5, barSec * 2), Math.round(rawOutroSec / barSec) * barSec)
    ).toFixed(2)
  );

  // Estimate vocal mid-band presence in intro & outro via zero-crossing / band-energy proxy
  const estimateMidPresence = (startSec: number, spanSec: number): number => {
    const startIdx = Math.max(0, Math.floor(startSec * sampleRate));
    const endIdx = Math.min(ch0.length - 2, Math.floor((startSec + spanSec) * sampleRate));
    if (endIdx <= startIdx + 256) return 0.28;
    let totalE = 0;
    let midDiffE = 0;
    for (let i = startIdx; i < endIdx; i += 4) {
      const s = ch0[i];
      const d = ch0[i + 1] - ch0[i];
      totalE += s * s;
      midDiffE += d * d;
    }
    if (totalE < 1e-7) return 0.1;
    const ratio = Math.sqrt(midDiffE / totalE);
    return Number(Math.max(0.12, Math.min(0.88, ratio * 0.95)).toFixed(2));
  };

  const vocalIntroDensity = estimateMidPresence(Math.min(2, durationSec * 0.05), 6);
  const vocalOutroDensity = estimateMidPresence(outroStartSec, Math.min(8, durationSec - outroStartSec));
  const energy = Number(Math.max(0.35, Math.min(0.96, avgPeak * 1.25)).toFixed(2));

  return {
    bpm,
    camelotKey,
    musicalKey,
    durationSec,
    introEndSec,
    outroStartSec,
    vocalIntroDensity,
    vocalOutroDensity,
    energy,
    hasSilenceTail,
    waveformPeaks,
  };
}
