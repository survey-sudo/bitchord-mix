import { computeWaveformPeaks } from "./audio-analyzer";
import { planAutoMixTransition } from "./automix-planner";
import {
  DspEngineConfig,
  LiveMixTelemetry,
  TrackItem,
  TransitionPlan,
} from "./automix-types";

interface DeckNodes {
  source: AudioBufferSourceNode | null;
  hpf: BiquadFilterNode;
  lowShelf: BiquadFilterNode;
  midPeak: BiquadFilterNode;
  highShelf: BiquadFilterNode;
  gain: GainNode;
  echoSend: GainNode;
  startedAtCtxTime: number;
  bufferOffsetSec: number;
  currentRate: number;
  isPlaying: boolean;
  trackId: string | number | null;
}

const KEY_ROOT_MIDI: Record<string, { root: number; minor: boolean }> = {
  "A Minor": { root: 57, minor: true },
  "E Minor": { root: 52, minor: true },
  "C Major": { root: 60, minor: false },
  "F Minor": { root: 53, minor: true },
  "G Major": { root: 55, minor: false },
  "A Major": { root: 57, minor: false },
  "Eb Minor": { root: 51, minor: true },
  "D Minor": { root: 50, minor: true },
};

function midiToFreq(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

/**
 * Generates a rich, musical stereo AudioBuffer tailored to each track's BPM, Key,
 * Intro/Outro structure, Vocal lead presence, and Curated vs Non-Curated traits.
 */
function renderSynthesizedTrackBuffer(
  ctx: AudioContext,
  track: TrackItem
): AudioBuffer {
  const sr = ctx.sampleRate;
  const duration = Math.max(24, Math.min(60, track.durationSec));
  const totalSamples = Math.floor(sr * duration);
  const buffer = ctx.createBuffer(2, totalSamples, sr);
  const left = buffer.getChannelData(0);
  const right = buffer.getChannelData(1);

  const keyInfo = KEY_ROOT_MIDI[track.musicalKey] ?? { root: 57, minor: true };
  const scaleIntervals = keyInfo.minor
    ? [0, 2, 3, 5, 7, 8, 10]
    : [0, 2, 4, 5, 7, 9, 11];

  // 4-chord progression degrees (i - VI - III - VII for minor, I - V - vi - IV for major)
  const progDegrees = keyInfo.minor ? [0, 5, 2, 6] : [0, 4, 5, 3];
  const preset = track.synthPreset || "deep_house_8a";
  const isHalfTimeTrap = preset.includes("trap") || track.bpm < 88;
  const isBreakbeat = preset.includes("garage") || preset.includes("breaks") || track.bpm >= 134;
  const isVocalPop = preset.includes("vocal") || track.vocalOutroDensity >= 0.55;

  const beatSec = 60 / track.bpm;
  const barSec = beatSec * 4;
  const silenceStartSec = track.hasSilenceTail ? duration - 3.3 : duration + 10;

  // Deterministic pseudo-noise generator for crisp hats/claps/applause
  let rngState = 1337 + Math.round(track.bpm * 17);
  const nextNoise = () => {
    rngState = (rngState * 1664525 + 1013904223) >>> 0;
    return (rngState / 2147483648) - 1.0;
  };

  let subPhase = 0;
  let leadPhase = 0;

  for (let i = 0; i < totalSamples; i++) {
    const t = i / sr;

    if (t >= silenceStartSec) {
      // Simulate decaying applause / room tail fading into dead silence on non-curated live tracks
      const tailElapsed = t - silenceStartSec;
      if (tailElapsed < 1.15) {
        const decay = Math.exp(-tailElapsed * 3.4) * 0.16;
        const n = nextNoise();
        left[i] = n * decay;
        right[i] = -n * decay * 0.9;
      } else {
        left[i] = 0;
        right[i] = 0;
      }
      continue;
    }

    const beatFloat = t / beatSec;
    const beatIndex = Math.floor(beatFloat);
    const beatFrac = beatFloat - beatIndex;
    const barIndex = Math.floor(t / barSec);
    const beatInBar = beatIndex % 4;
    const sixteenthIndex = Math.floor(beatFloat * 4) % 16;
    const sixteenthFrac = (beatFloat * 4) % 1;

    const inIntro = t < track.introEndSec;
    const inOutro = t >= track.outroStartSec;
    const inBody = !inIntro && !inOutro;

    const deg = progDegrees[barIndex % 4];
    const chordRootMidi = keyInfo.root - 12 + scaleIntervals[deg % 7];
    const thirdMidi = keyInfo.root + scaleIntervals[(deg + 2) % 7];
    const fifthMidi = keyInfo.root + scaleIntervals[(deg + 4) % 7];
    const seventhMidi = keyInfo.root + scaleIntervals[(deg + 6) % 7];

    let sampleL = 0;
    let sampleR = 0;

    // 1. DRUMS (Kick + Snare/Clap + Hi-Hats)
    let triggerKick = false;
    let kickFrac = beatFrac;

    if (isHalfTimeTrap) {
      // Half-time booming 808 pattern (Beat 0, syncopated 2.5)
      if (beatInBar === 0) {
        triggerKick = true;
        kickFrac = beatFrac;
      } else if (sixteenthIndex === 10) {
        triggerKick = true;
        kickFrac = sixteenthFrac * 0.35;
      }
    } else if (isBreakbeat) {
      // 2-step / Breakbeat syncopated kick (sixteenth 0 and 10)
      if (sixteenthIndex === 0 || sixteenthIndex === 10) {
        triggerKick = true;
        kickFrac = sixteenthFrac * 0.5;
      }
    } else {
      // Classic 4-on-the-floor club kick
      triggerKick = true;
      kickFrac = beatFrac;
    }

    if (triggerKick) {
      const kTime = kickFrac * beatSec;
      if (kTime < 0.28) {
        const pitchEnv = 49 + 115 * Math.exp(-kTime * 38);
        const ampEnv = Math.exp(-kTime * (isHalfTimeTrap ? 7.5 : 13.5));
        const kick = Math.sin(2 * Math.PI * pitchEnv * kTime) * ampEnv * 0.56;
        sampleL += kick;
        sampleR += kick;
      }
    }

    // Snare / Clap on backbeats (beat 2 in halftime, beats 1 & 3 otherwise)
    const isSnareBeat = isHalfTimeTrap ? beatInBar === 2 : beatInBar === 1 || beatInBar === 3;
    if (isSnareBeat && (!inIntro || t > track.introEndSec * 0.5)) {
      const sTime = beatFrac * beatSec;
      if (sTime < 0.16) {
        const snareEnv = Math.exp(-sTime * 24);
        const body = Math.sin(2 * Math.PI * 195 * sTime) * Math.exp(-sTime * 35) * 0.18;
        const snap = nextNoise() * snareEnv * 0.24;
        sampleL += snap * 1.05 + body;
        sampleR += snap * 0.95 + body;
      }
    }

    // Crisp Hi-Hats (offbeat open hat + 16th closed groove)
    const hTime = sixteenthFrac * (beatSec * 0.25);
    const isOffbeatHat = sixteenthIndex % 4 === 2;
    if (hTime < (isOffbeatHat ? 0.095 : 0.035)) {
      const hatDecay = isOffbeatHat ? 34 : 85;
      const hatGain = isOffbeatHat ? 0.12 : sixteenthIndex % 2 === 0 ? 0.06 : 0.035;
      const hat = nextNoise() * Math.exp(-hTime * hatDecay) * hatGain;
      sampleL += hat * 0.85;
      sampleR += hat * 1.15;
    }

    // 2. SUB-BASS / GROOVE BASSLINE
    const bassFreq = midiToFreq(chordRootMidi - 12);
    // Sidechain ducking against kick
    const sidechain = triggerKick ? Math.min(1, 0.22 + beatFrac * 1.35) : 0.95;
    subPhase += (2 * Math.PI * bassFreq) / sr;
    if (subPhase > Math.PI * 2) subPhase -= Math.PI * 2;
    const bassGain = inIntro && t < track.introEndSec * 0.5 ? 0.14 : 0.31;
    const bassWave =
      (Math.sin(subPhase) * 0.78 + Math.tanh(Math.sin(subPhase * 2) * 1.6) * 0.22) *
      bassGain *
      sidechain;
    sampleL += bassWave;
    sampleR += bassWave;

    // 3. HARMONIC PAD / CHORD STABS (stereo detuned warmth)
    const padGain =
      (inBody ? 0.16 : inOutro ? 0.13 : 0.11) * sidechain;
    const f1 = midiToFreq(chordRootMidi + 12);
    const f3 = midiToFreq(thirdMidi);
    const f5 = midiToFreq(fifthMidi);
    const f7 = midiToFreq(seventhMidi);

    const chordL =
      Math.sin(2 * Math.PI * f1 * 1.002 * t) +
      Math.sin(2 * Math.PI * f3 * 0.998 * t) * 0.85 +
      Math.sin(2 * Math.PI * f5 * 1.003 * t) * 0.75 +
      Math.sin(2 * Math.PI * f7 * t) * 0.55;
    const chordR =
      Math.sin(2 * Math.PI * f1 * 0.998 * t) +
      Math.sin(2 * Math.PI * f3 * 1.003 * t) * 0.85 +
      Math.sin(2 * Math.PI * f5 * 0.997 * t) * 0.75 +
      Math.sin(2 * Math.PI * f7 * 1.002 * t) * 0.55;

    sampleL += chordL * 0.25 * padGain;
    sampleR += chordR * 0.25 * padGain;

    // 4. MELODIC ARP / VOCAL-FORMANT PRESENCE LEAD (especially active when vocal density is high!)
    const activeVocalDensity = inIntro
      ? track.vocalIntroDensity
      : inOutro
      ? track.vocalOutroDensity
      : isVocalPop
      ? 0.75
      : 0.42;

    if (activeVocalDensity > 0.24) {
      const noteStep = Math.floor(beatFloat * 2) % 8;
      const arpPattern = [0, 2, 4, 6, 4, 2, 1, 4];
      const leadScaleIdx = (deg + arpPattern[noteStep]) % 7;
      const leadMidi = keyInfo.root + 12 + scaleIntervals[leadScaleIdx];
      const vibrato = isVocalPop ? 1 + Math.sin(2 * Math.PI * 5.4 * t) * 0.0045 : 1;
      const leadFreq = midiToFreq(leadMidi) * vibrato;

      leadPhase += (2 * Math.PI * leadFreq) / sr;
      if (leadPhase > Math.PI * 2) leadPhase -= Math.PI * 2;

      const noteEnv = Math.exp(-((beatFloat * 2) % 1) * (isVocalPop ? 2.1 : 4.2));
      // Rich vocal-band harmonics in 600Hz..2.4kHz so our mid-scoop isolator visibly & audibly carves it!
      const formantWave =
        Math.sin(leadPhase) * 0.5 +
        Math.sin(leadPhase * 2) * 0.34 +
        Math.sin(leadPhase * 3) * 0.22;
      const leadAmp = formantWave * noteEnv * activeVocalDensity * 0.21;
      sampleL += leadAmp * 1.08;
      sampleR += leadAmp * 0.92;
    }

    // Gentle master soft-clipper & fade guard at track boundaries
    const edgeIn = Math.min(1, t / 0.15);
    const edgeOut = track.hasSilenceTail
      ? 1
      : Math.min(1, Math.max(0, (duration - t) / 1.4));

    left[i] = Math.tanh(sampleL * 1.15) * 0.82 * edgeIn * edgeOut;
    right[i] = Math.tanh(sampleR * 1.15) * 0.82 * edgeIn * edgeOut;
  }

  return buffer;
}

export class AutoMixWebAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private echoDelay: DelayNode | null = null;
  private echoFilter: BiquadFilterNode | null = null;
  private echoFeedback: GainNode | null = null;
  private echoWetOut: GainNode | null = null;

  private deckA: DeckNodes | null = null;
  private deckB: DeckNodes | null = null;

  private bufferCache = new Map<string | number, AudioBuffer>();
  private waveformCache = new Map<string | number, number[]>();

  private queue: TrackItem[] = [];
  private config: DspEngineConfig;
  private autoMixEnabled = true;

  private activeIndex = 0;
  private isPlaying = false;
  private isMixing = false;
  private activePlan: TransitionPlan | null = null;
  private mixStartCtxTime = 0;

  private rafId: number | null = null;
  private onTelemetry: ((t: LiveMixTelemetry) => void) | null = null;

  constructor(initialConfig: DspEngineConfig) {
    this.config = initialConfig;
  }

  public setTelemetryListener(cb: (t: LiveMixTelemetry) => void) {
    this.onTelemetry = cb;
  }

  public updateConfig(newConfig: DspEngineConfig) {
    this.config = newConfig;
    this.recomputePlan();
    this.emitSnapshot();
  }

  public setAutoMixEnabled(enabled: boolean) {
    this.autoMixEnabled = enabled;
    this.recomputePlan();
    this.emitSnapshot();
  }

  public getAutoMixEnabled(): boolean {
    return this.autoMixEnabled;
  }

  public setQueue(tracks: TrackItem[], preserveCurrent = true) {
    const currentId = this.queue[this.activeIndex]?.id;
    this.queue = tracks;
    if (preserveCurrent && currentId !== undefined) {
      const idx = tracks.findIndex((t) => t.id === currentId);
      this.activeIndex = idx >= 0 ? idx : 0;
    } else if (this.activeIndex >= tracks.length) {
      this.activeIndex = 0;
    }
    this.recomputePlan();
    this.emitSnapshot();
  }

  public registerDecodedBuffer(trackId: string | number, buffer: AudioBuffer, peaks?: number[]) {
    this.bufferCache.set(trackId, buffer);
    this.waveformCache.set(trackId, peaks ?? computeWaveformPeaks(buffer, 140));
  }

  public getWaveformPeaks(track: TrackItem): number[] {
    if (track.waveformPeaks && track.waveformPeaks.length > 0) {
      return track.waveformPeaks;
    }
    const cached = this.waveformCache.get(track.id);
    if (cached) return cached;

    // Deterministic synthetic waveform silhouette before AudioContext wakes up
    const bins = 140;
    const out: number[] = [];
    for (let i = 0; i < bins; i++) {
      const sec = (i / bins) * track.durationSec;
      if (track.hasSilenceTail && sec > track.durationSec - 3.3) {
        out.push(0.06);
        continue;
      }
      const inIntro = sec < track.introEndSec;
      const inOutro = sec >= track.outroStartSec;
      const base = inIntro ? 0.42 + (sec / Math.max(1, track.introEndSec)) * 0.35 : inOutro ? 0.55 : 0.82;
      const mod = Math.abs(Math.sin(i * 0.73 + track.bpm * 0.1)) * 0.18;
      out.push(Number(Math.min(0.98, Math.max(0.08, base * track.energy + mod)).toFixed(2)));
    }
    this.waveformCache.set(track.id, out);
    return out;
  }

  public async decodeFileToBuffer(file: File): Promise<AudioBuffer> {
    this.ensureContext();
    const arrayBuffer = await file.arrayBuffer();
    return await this.ctx!.decodeAudioData(arrayBuffer);
  }

  private ensureContext() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") {
        void this.ctx.resume();
      }
      return;
    }
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AudioCtx();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.88;
    this.masterGain.connect(this.ctx.destination);

    // Auxiliary Tempo-Synced Dub Echo Freeze Network
    this.echoDelay = this.ctx.createDelay(2.0);
    this.echoDelay.delayTime.value = 0.375;
    this.echoFilter = this.ctx.createBiquadFilter();
    this.echoFilter.type = "bandpass";
    this.echoFilter.frequency.value = 1050;
    this.echoFilter.Q.value = 1.15;
    this.echoFeedback = this.ctx.createGain();
    this.echoFeedback.gain.value = 0.56;
    this.echoWetOut = this.ctx.createGain();
    this.echoWetOut.gain.value = 0.0;

    this.echoDelay.connect(this.echoFilter);
    this.echoFilter.connect(this.echoFeedback);
    this.echoFeedback.connect(this.echoDelay);
    this.echoFilter.connect(this.echoWetOut);
    this.echoWetOut.connect(this.masterGain);

    this.deckA = this.createDeckChain();
    this.deckB = this.createDeckChain();
  }

  private createDeckChain(): DeckNodes {
    const ctx = this.ctx!;
    const hpf = ctx.createBiquadFilter();
    hpf.type = "highpass";
    hpf.frequency.value = 22;
    hpf.Q.value = 0.85;

    const lowShelf = ctx.createBiquadFilter();
    lowShelf.type = "lowshelf";
    lowShelf.frequency.value = 185;
    lowShelf.gain.value = 0;

    const midPeak = ctx.createBiquadFilter();
    midPeak.type = "peaking";
    midPeak.frequency.value = 1200;
    midPeak.Q.value = 1.1;
    midPeak.gain.value = 0;

    const highShelf = ctx.createBiquadFilter();
    highShelf.type = "highshelf";
    highShelf.frequency.value = 3800;
    highShelf.gain.value = 0;

    const gain = ctx.createGain();
    gain.gain.value = 1;

    const echoSend = ctx.createGain();
    echoSend.gain.value = 0;

    hpf.connect(lowShelf);
    lowShelf.connect(midPeak);
    midPeak.connect(highShelf);
    highShelf.connect(gain);
    gain.connect(this.masterGain!);

    highShelf.connect(echoSend);
    echoSend.connect(this.echoDelay!);

    return {
      source: null,
      hpf,
      lowShelf,
      midPeak,
      highShelf,
      gain,
      echoSend,
      startedAtCtxTime: 0,
      bufferOffsetSec: 0,
      currentRate: 1.0,
      isPlaying: false,
      trackId: null,
    };
  }

  private ensureTrackBuffer(track: TrackItem): AudioBuffer {
    this.ensureContext();
    let buf = this.bufferCache.get(track.id);
    if (!buf) {
      buf = renderSynthesizedTrackBuffer(this.ctx!, track);
      this.bufferCache.set(track.id, buf);
      this.waveformCache.set(track.id, computeWaveformPeaks(buf, 140));
    }
    return buf;
  }

  private getNextIndex(): number {
    if (this.queue.length <= 1) return 0;
    return (this.activeIndex + 1) % this.queue.length;
  }

  private recomputePlan() {
    if (this.queue.length === 0) {
      this.activePlan = null;
      return;
    }
    const trackA = this.queue[this.activeIndex];
    const trackB = this.queue[this.getNextIndex()];
    if (!trackA || !trackB) {
      this.activePlan = null;
      return;
    }
    this.activePlan = planAutoMixTransition(trackA, trackB, this.config);
  }

  private stopDeck(deck: DeckNodes | null) {
    if (!deck) return;
    if (deck.source) {
      try {
        deck.source.onended = null;
        deck.source.stop();
        deck.source.disconnect();
      } catch {
        // Ignore already stopped source
      }
      deck.source = null;
    }
    deck.isPlaying = false;
    deck.currentRate = 1.0;
    deck.hpf.frequency.value = 22;
    deck.lowShelf.gain.value = 0;
    deck.midPeak.gain.value = 0;
    deck.highShelf.gain.value = 0;
    deck.echoSend.gain.value = 0;
  }

  private startDeckAt(deck: DeckNodes, track: TrackItem, offsetSec: number, initialGain: number, rate = 1.0) {
    this.stopDeck(deck);
    const buffer = this.ensureTrackBuffer(track);
    const safeOffset = Math.max(0, Math.min(buffer.duration - 0.2, offsetSec));
    const src = this.ctx!.createBufferSource();
    src.buffer = buffer;
    src.playbackRate.value = rate;
    src.connect(deck.hpf);

    deck.source = src;
    deck.trackId = track.id;
    deck.bufferOffsetSec = safeOffset;
    deck.startedAtCtxTime = this.ctx!.currentTime;
    deck.currentRate = rate;
    deck.gain.gain.value = initialGain;
    deck.isPlaying = true;
    src.start(0, safeOffset);
  }

  private getDeckPosition(deck: DeckNodes | null): number {
    if (!deck || !deck.isPlaying || !this.ctx) {
      return deck ? deck.bufferOffsetSec : 0;
    }
    const elapsed = (this.ctx.currentTime - deck.startedAtCtxTime) * deck.currentRate;
    return deck.bufferOffsetSec + Math.max(0, elapsed);
  }

  public playTrackAtIndex(index: number, offsetSec = 0) {
    if (this.queue.length === 0) return;
    this.ensureContext();
    this.activeIndex = ((index % this.queue.length) + this.queue.length) % this.queue.length;
    this.isMixing = false;
    this.recomputePlan();

    this.stopDeck(this.deckA);
    this.stopDeck(this.deckB);
    if (this.echoWetOut) this.echoWetOut.gain.value = 0;

    const trackA = this.queue[this.activeIndex];
    this.startDeckAt(this.deckA!, trackA, offsetSec, 1.0, 1.0);
    this.isPlaying = true;
    this.startLoop();
    this.emitSnapshot();
  }

  public togglePlayPause() {
    if (this.queue.length === 0) return;
    if (!this.isPlaying) {
      this.ensureContext();
      const resumeOffset = this.deckA ? this.deckA.bufferOffsetSec : 0;
      this.playTrackAtIndex(this.activeIndex, resumeOffset);
    } else {
      const posA = this.getDeckPosition(this.deckA);
      this.stopDeck(this.deckA);
      this.stopDeck(this.deckB);
      if (this.deckA) this.deckA.bufferOffsetSec = posA;
      if (this.echoWetOut) this.echoWetOut.gain.value = 0;
      this.isPlaying = false;
      this.isMixing = false;
      this.stopLoop();
      this.emitSnapshot();
    }
  }

  public seekDeckA(targetSec: number) {
    if (this.queue.length === 0) return;
    const trackA = this.queue[this.activeIndex];
    const clamped = Math.max(0, Math.min(trackA.durationSec - 0.5, targetSec));
    if (this.isPlaying) {
      this.playTrackAtIndex(this.activeIndex, clamped);
    } else {
      if (this.deckA) this.deckA.bufferOffsetSec = clamped;
      this.emitSnapshot();
    }
  }

  /**
   * Jumps directly to 3.2 seconds before the calculated Sweet-Spot Cue-Out
   * so engineers/listeners can immediately experience the AutoMix transition!
   */
  public triggerSweetSpotPreview() {
    if (this.queue.length === 0) return;
    this.recomputePlan();
    const trackA = this.queue[this.activeIndex];
    const triggerSec = this.autoMixEnabled && this.activePlan
      ? this.activePlan.cueOutSec
      : Math.max(6, trackA.durationSec - 7.5);
    const previewStart = Math.max(0, triggerSec - 3.0);
    this.playTrackAtIndex(this.activeIndex, previewStart);
  }

  public skipNext() {
    this.playTrackAtIndex(this.getNextIndex(), 0);
  }

  public skipPrev() {
    const pos = this.getDeckPosition(this.deckA);
    if (pos > 4) {
      this.seekDeckA(0);
    } else {
      const prevIdx = (this.activeIndex - 1 + this.queue.length) % Math.max(1, this.queue.length);
      this.playTrackAtIndex(prevIdx, 0);
    }
  }

  private beginTransition() {
    if (!this.ctx || !this.deckA || !this.deckB || this.isMixing) return;
    const nextIdx = this.getNextIndex();
    const trackA = this.queue[this.activeIndex];
    const trackB = this.queue[nextIdx];
    if (!trackA || !trackB) return;

    this.recomputePlan();
    const plan = this.activePlan!;
    this.isMixing = true;
    this.mixStartCtxTime = this.ctx.currentTime;

    if (this.autoMixEnabled) {
      // Configure tempo-synced 3/4-beat dub delay time based on Deck A BPM
      if (this.echoDelay) {
        const threeQuarterBeat = Math.min(1.4, (60 / trackA.bpm) * 0.75);
        this.echoDelay.delayTime.value = threeQuarterBeat;
      }

      const initialRateB = 1 + plan.stretchPctB / 100;
      this.startDeckAt(this.deckB, trackB, plan.cueInSec, 0.001, initialRateB);
      // Incoming Deck B starts with sub-bass fully cut (-24 dB) to prevent double-kick muddiness!
      this.deckB.lowShelf.gain.value = -24;
    } else {
      // Naive standard crossfade: starts at 0.0s, unstretched 1.0x, no EQ bass swap!
      this.startDeckAt(this.deckB, trackB, 0, 0.001, 1.0);
      this.deckB.lowShelf.gain.value = 0;
    }
  }

  private updateDeckRatePreservingPos(deck: DeckNodes, newRate: number) {
    if (!deck.isPlaying || !deck.source || !this.ctx) return;
    if (Math.abs(newRate - deck.currentRate) < 0.0005) return;
    const currentPos = this.getDeckPosition(deck);
    deck.bufferOffsetSec = currentPos;
    deck.startedAtCtxTime = this.ctx.currentTime;
    deck.currentRate = newRate;
    deck.source.playbackRate.value = newRate;
  }

  private completeTransition() {
    if (!this.deckA || !this.deckB) return;
    const nextIdx = this.getNextIndex();

    // Promote Deck B to Deck A seamlessly without dropping a single sample!
    this.stopDeck(this.deckA);
    const oldDeckA = this.deckA;
    this.deckA = this.deckB;
    this.deckB = oldDeckA;

    // Normalize promoted Deck A back to clean unity state
    this.updateDeckRatePreservingPos(this.deckA, 1.0);
    this.deckA.gain.gain.value = 1.0;
    this.deckA.hpf.frequency.value = 22;
    this.deckA.lowShelf.gain.value = 0;
    this.deckA.midPeak.gain.value = 0;
    this.deckA.highShelf.gain.value = 0;
    this.deckA.echoSend.gain.value = 0;
    if (this.echoWetOut) this.echoWetOut.gain.value = 0;

    this.activeIndex = nextIdx;
    this.isMixing = false;
    this.recomputePlan();
  }

  private tick = () => {
    if (!this.isPlaying || !this.ctx || !this.deckA || this.queue.length === 0) {
      return;
    }

    const trackA = this.queue[this.activeIndex];
    const posA = this.getDeckPosition(this.deckA);
    const plan = this.activePlan;

    if (!this.isMixing) {
      const triggerSec =
        this.autoMixEnabled && plan
          ? plan.cueOutSec
          : Math.max(4, trackA.durationSec - 6.0);

      if (posA >= triggerSec) {
        this.beginTransition();
      } else if (posA >= trackA.durationSec - 0.15) {
        this.skipNext();
      }
    } else if (this.deckB && plan) {
      const mixDuration = this.autoMixEnabled ? plan.mixDurationSec : 6.0;
      const elapsedMix = this.ctx.currentTime - this.mixStartCtxTime;
      const p = Math.max(0, Math.min(1, elapsedMix / mixDuration));

      if (this.autoMixEnabled) {
        // 1. Equal-power S-curve gain crossfade
        const smoothP = p * p * (3 - 2 * p);
        const gainA = Math.cos(smoothP * Math.PI * 0.5);
        const gainB = Math.sin(smoothP * Math.PI * 0.5);
        this.deckA.gain.gain.value = gainA;
        this.deckB.gain.gain.value = gainB;

        // 2. Real-time phase-locked time-stretch tempo ramp!
        // Deck A gradually stretches from 1.00 -> (1 + stretchPctA/100)
        // Deck B gradually relaxes from (1 + stretchPctB/100) -> 1.00 native tempo!
        const rateA = 1 + (plan.stretchPctA / 100) * smoothP;
        const rateB = 1 + (plan.stretchPctB / 100) * (1 - smoothP);
        this.updateDeckRatePreservingPos(this.deckA, rateA);
        this.updateDeckRatePreservingPos(this.deckB, rateB);

        // 3. 3-Band Isolator Sub-Bass Swap at exact midpoint downbeat
        const swapCenter = plan.bassSwapProgressPoint;
        const sharpness = Math.max(3, this.config.bassSwapSharpness * 14);
        const swapSigmoid = 1 / (1 + Math.exp(-sharpness * (p - swapCenter)));
        this.deckA.lowShelf.gain.value = -24 * swapSigmoid;
        this.deckB.lowShelf.gain.value = -24 * (1 - swapSigmoid);

        // 4. Vocal Presence Mid-Scoop (350Hz-3.4kHz) to eliminate vocal-on-vocal clash
        const midEnvelope = Math.sin(p * Math.PI);
        this.deckA.midPeak.gain.value = plan.vocalMidScoopDb * midEnvelope;
        this.deckB.midPeak.gain.value = -2.0 * (1 - p);

        // 5. Resonant High-Pass Filter Wash & Dub Echo Freeze Tail (especially on ECHO_FREEZE_WASH_OUT)
        if (plan.strategy === "ECHO_FREEZE_WASH_OUT") {
          const hpfHz = 28 + Math.pow(p, 1.5) * 1850;
          this.deckA.hpf.frequency.value = hpfHz;
          const echoBell = Math.sin(Math.min(1, p * 1.15) * Math.PI);
          this.deckA.echoSend.gain.value = plan.echoFreezeWetPeak * echoBell;
          if (this.echoWetOut) this.echoWetOut.gain.value = 0.65 * echoBell;
        } else {
          const gentleHpf = p > 0.55 ? 24 + ((p - 0.55) / 0.45) * 310 : 22;
          this.deckA.hpf.frequency.value = gentleHpf;
          this.deckA.echoSend.gain.value = plan.echoFreezeWetPeak * Math.sin(p * Math.PI);
          if (this.echoWetOut) this.echoWetOut.gain.value = 0.25 * Math.sin(p * Math.PI);
        }
      } else {
        // Naive Crossfade (AutoMix OFF): linear crossfade, no time stretch, no EQ swap!
        this.deckA.gain.gain.value = 1 - p;
        this.deckB.gain.gain.value = p;
      }

      if (p >= 1) {
        this.completeTransition();
      }
    }

    this.emitSnapshot();
    this.rafId = window.requestAnimationFrame(this.tick);
  };

  private startLoop() {
    this.stopLoop();
    this.rafId = window.requestAnimationFrame(this.tick);
  }

  private stopLoop() {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  public emitSnapshot() {
    if (!this.onTelemetry) return;
    const trackA = this.queue[this.activeIndex];
    const nextIdx = this.getNextIndex();
    const trackB = this.queue[nextIdx];

    const posA = this.getDeckPosition(this.deckA);
    const posB = this.isMixing ? this.getDeckPosition(this.deckB) : this.activePlan?.cueInSec ?? 0;

    const rateA = this.deckA?.currentRate ?? 1.0;
    const rateB = this.isMixing ? this.deckB?.currentRate ?? 1.0 : 1.0;
    const curBpmA = (trackA?.bpm ?? 120) * rateA;
    const curBpmB = (trackB?.bpm ?? 120) * rateB;

    const beatDuration = 60 / Math.max(40, curBpmA);
    const totalBeats = posA / beatDuration;
    const beatPhase = totalBeats - Math.floor(totalBeats);
    const barBeatIndex = Math.floor(totalBeats) % 4;

    const mixDuration = this.autoMixEnabled
      ? this.activePlan?.mixDurationSec ?? 8
      : 6;
    const mixProgress =
      this.isMixing && this.ctx
        ? Math.max(0, Math.min(1, (this.ctx.currentTime - this.mixStartCtxTime) / mixDuration))
        : 0;

    this.onTelemetry({
      isPlaying: this.isPlaying,
      isMixing: this.isMixing,
      autoMixEnabled: this.autoMixEnabled,
      mixProgress,
      activeTrackIndex: this.activeIndex,
      nextTrackIndex: nextIdx,
      deckAPositionSec: posA,
      deckBPositionSec: posB,
      deckADurationSec: trackA?.durationSec ?? 40,
      deckBDurationSec: trackB?.durationSec ?? 40,
      deckACurrentBpm: Number(curBpmA.toFixed(1)),
      deckBCurrentBpm: Number(curBpmB.toFixed(1)),
      deckARate: Number(rateA.toFixed(4)),
      deckBRate: Number(rateB.toFixed(4)),
      deckAGain: Number((this.deckA?.gain.gain.value ?? 1).toFixed(3)),
      deckBGain: Number((this.isMixing ? this.deckB?.gain.gain.value ?? 0 : 0).toFixed(3)),
      deckALowDb: Number((this.deckA?.lowShelf.gain.value ?? 0).toFixed(1)),
      deckBLowDb: Number((this.isMixing ? this.deckB?.lowShelf.gain.value ?? -24 : -24).toFixed(1)),
      deckAMidDb: Number((this.deckA?.midPeak.gain.value ?? 0).toFixed(1)),
      deckBMidDb: Number((this.isMixing ? this.deckB?.midPeak.gain.value ?? 0 : 0).toFixed(1)),
      deckAHpfHz: Math.round(this.deckA?.hpf.frequency.value ?? 22),
      echoWetMix: Number((this.deckA?.echoSend.gain.value ?? 0).toFixed(2)),
      beatPhase,
      barBeatIndex,
      activePlan: this.activePlan,
    });
  }

  public dispose() {
    this.stopLoop();
    this.stopDeck(this.deckA);
    this.stopDeck(this.deckB);
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
  }
}
