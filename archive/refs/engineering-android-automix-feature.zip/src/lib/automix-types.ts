export type TransitionStrategy =
  | "PHRASE_BEATMATCH_BASS_SWAP"
  | "VOCAL_DUCK_STEM_BLEND"
  | "HALF_DOUBLE_TIME_LOCK"
  | "ECHO_FREEZE_WASH_OUT"
  | "COLD_END_DROP_CUT";

export interface TrackItem {
  id: number | string;
  slug: string;
  title: string;
  artist: string;
  genre: string;
  bpm: number;
  camelotKey: string;
  musicalKey: string;
  durationSec: number;
  isCurated: boolean;
  introEndSec: number;
  outroStartSec: number;
  vocalOutroDensity: number;
  vocalIntroDensity: number;
  energy: number;
  hasSilenceTail: boolean;
  synthPreset: string;
  coverGradient: string;
  isLocalUpload?: boolean;
  waveformPeaks?: number[];
}

export interface DspEngineConfig {
  id?: number;
  name: string;
  description: string;
  maxStretchPct: number;
  defaultMixBars: number;
  bassSwapSharpness: number;
  vocalDuckDb: number;
  harmonicWeight: number;
  enableHalfDoubleLock: boolean;
  enableEchoFreezeFallback: boolean;
  silenceGateDb: number;
  npuDelegate: string;
  isBuiltIn?: boolean;
}

export interface TransitionPlan {
  strategy: TransitionStrategy;
  strategyLabel: string;
  strategyShortBadge: string;
  cueOutSec: number;
  cueInSec: number;
  mixDurationSec: number;
  mixBars: number;
  effectiveTargetBpmForA: number;
  effectiveStartBpmForB: number;
  stretchPctA: number;
  stretchPctB: number;
  tempoRatioMode: "1:1 Direct" | "1:2 Double-Time Lock" | "2:1 Half-Time Lock" | "Native Unstretched (Echo Wash)";
  camelotDistance: number;
  harmonicRelation: string;
  vocalClashRisk: number; // 0..1
  bassSwapProgressPoint: number; // 0..1 (typically 0.50 midpoint downbeat)
  vocalMidScoopDb: number;
  echoFreezeWetPeak: number;
  androidAutoMixScore: number;
  appleBaselineScore: number;
  crossfadeBaselineScore: number;
  reasoningBullets: string[];
}

export interface LiveMixTelemetry {
  isPlaying: boolean;
  isMixing: boolean;
  autoMixEnabled: boolean;
  mixProgress: number; // 0..1 when mixing, 0 otherwise
  activeTrackIndex: number;
  nextTrackIndex: number;
  deckAPositionSec: number;
  deckBPositionSec: number;
  deckADurationSec: number;
  deckBDurationSec: number;
  deckACurrentBpm: number;
  deckBCurrentBpm: number;
  deckARate: number;
  deckBRate: number;
  deckAGain: number;
  deckBGain: number;
  deckALowDb: number;
  deckBLowDb: number;
  deckAMidDb: number;
  deckBMidDb: number;
  deckAHpfHz: number;
  echoWetMix: number;
  beatPhase: number; // 0..1 beat pulse
  barBeatIndex: number; // 0..3 (1, 2, 3, 4)
  activePlan: TransitionPlan | null;
}
