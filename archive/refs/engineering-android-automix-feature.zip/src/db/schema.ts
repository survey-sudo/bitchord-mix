import {
  pgTable,
  serial,
  text,
  doublePrecision,
  integer,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const tracks = pgTable("tracks", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  artist: text("artist").notNull(),
  genre: text("genre").notNull(),
  bpm: doublePrecision("bpm").notNull(),
  camelotKey: text("camelot_key").notNull(),
  musicalKey: text("musical_key").notNull(),
  durationSec: doublePrecision("duration_sec").notNull(),
  isCurated: boolean("is_curated").notNull().default(true),
  introEndSec: doublePrecision("intro_end_sec").notNull(),
  outroStartSec: doublePrecision("outro_start_sec").notNull(),
  vocalOutroDensity: doublePrecision("vocal_outro_density").notNull().default(0.15),
  vocalIntroDensity: doublePrecision("vocal_intro_density").notNull().default(0.15),
  energy: doublePrecision("energy").notNull().default(0.75),
  hasSilenceTail: boolean("has_silence_tail").notNull().default(false),
  synthPreset: text("synth_preset").notNull(),
  coverGradient: text("cover_gradient").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const dspPresets = pgTable("dsp_presets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  maxStretchPct: doublePrecision("max_stretch_pct").notNull().default(10.0),
  defaultMixBars: integer("default_mix_bars").notNull().default(8),
  bassSwapSharpness: doublePrecision("bass_swap_sharpness").notNull().default(0.82),
  vocalDuckDb: doublePrecision("vocal_duck_db").notNull().default(-9.5),
  harmonicWeight: doublePrecision("harmonic_weight").notNull().default(0.75),
  enableHalfDoubleLock: boolean("enable_half_double_lock").notNull().default(true),
  enableEchoFreezeFallback: boolean("enable_echo_freeze_fallback").notNull().default(true),
  silenceGateDb: doublePrecision("silence_gate_db").notNull().default(-42.0),
  npuDelegate: text("npu_delegate").notNull().default("AUTO_NNAPI_GPU"),
  isBuiltIn: boolean("is_built_in").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const transitionEvaluations = pgTable("transition_evaluations", {
  id: serial("id").primaryKey(),
  fromTrackTitle: text("from_track_title").notNull(),
  toTrackTitle: text("to_track_title").notNull(),
  isNonCuratedPair: boolean("is_non_curated_pair").notNull().default(false),
  fromBpm: doublePrecision("from_bpm").notNull(),
  toBpm: doublePrecision("to_bpm").notNull(),
  fromCamelot: text("from_camelot").notNull(),
  toCamelot: text("to_camelot").notNull(),
  strategyUsed: text("strategy_used").notNull(),
  stretchRatioPct: doublePrecision("stretch_ratio_pct").notNull(),
  mixDurationSec: doublePrecision("mix_duration_sec").notNull(),
  cueOutSec: doublePrecision("cue_out_sec").notNull(),
  cueInSec: doublePrecision("cue_in_sec").notNull(),
  androidAutoMixScore: integer("android_automix_score").notNull(),
  appleBaselineScore: integer("apple_baseline_score").notNull(),
  crossfadeBaselineScore: integer("crossfade_baseline_score").notNull(),
  notes: text("notes").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const deviceBenchmarks = pgTable("device_benchmarks", {
  id: serial("id").primaryKey(),
  deviceName: text("device_name").notNull(),
  socTier: text("soc_tier").notNull(),
  delegateUsed: text("delegate_used").notNull(),
  decode30sMs: doublePrecision("decode_30s_ms").notNull(),
  modelInferenceMs: doublePrecision("model_inference_ms").notNull(),
  dspCpuLoadPct: doublePrecision("dsp_cpu_load_pct").notNull(),
  peakRamMb: doublePrecision("peak_ram_mb").notNull(),
  batteryDrainPctPerHr: doublePrecision("battery_drain_pct_per_hr").notNull(),
  nonCuratedPassRatePct: doublePrecision("non_curated_pass_rate_pct").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type TrackRecord = typeof tracks.$inferSelect;
export type NewTrackRecord = typeof tracks.$inferInsert;
export type DspPresetRecord = typeof dspPresets.$inferSelect;
export type TransitionEvaluationRecord = typeof transitionEvaluations.$inferSelect;
export type DeviceBenchmarkRecord = typeof deviceBenchmarks.$inferSelect;
