import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "PulseMix — Android On-Device AutoMix Engine & DSP Workbench",
  description:
    "Reverse-engineered DJ-grade AutoMix for Android music players with real-time on-device ML transition planning, WSOLA beat-matching, 3-band bass swap, and non-curated local file support.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-[#07090e] text-slate-100 antialiased selection:bg-cyan-500/30 selection:text-cyan-200">
        {children}
      </body>
    </html>
  );
}
