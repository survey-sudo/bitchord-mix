import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { dspPresets } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(dspPresets).orderBy(asc(dspPresets.id));
    return NextResponse.json({ presets: rows });
  } catch (err) {
    console.error("Failed to fetch presets:", err);
    return NextResponse.json({ error: "Failed to fetch presets" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim() || "Custom AutoMix Profile";
    const description =
      String(body.description ?? "").trim() ||
      "Custom engineer-tuned Android AutoMix DSP & ML profile.";

    const [created] = await db
      .insert(dspPresets)
      .values({
        name,
        description,
        maxStretchPct: Number(body.maxStretchPct ?? 10.0),
        defaultMixBars: Number(body.defaultMixBars ?? 8),
        bassSwapSharpness: Number(body.bassSwapSharpness ?? 0.82),
        vocalDuckDb: Number(body.vocalDuckDb ?? -9.5),
        harmonicWeight: Number(body.harmonicWeight ?? 0.75),
        enableHalfDoubleLock: Boolean(body.enableHalfDoubleLock ?? true),
        enableEchoFreezeFallback: Boolean(body.enableEchoFreezeFallback ?? true),
        silenceGateDb: Number(body.silenceGateDb ?? -42.0),
        npuDelegate: String(body.npuDelegate ?? "AUTO_NNAPI_GPU"),
        isBuiltIn: false,
      })
      .returning();

    return NextResponse.json({ preset: created }, { status: 201 });
  } catch (err) {
    console.error("Failed to save preset:", err);
    return NextResponse.json({ error: "Failed to save preset" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const idParam = req.nextUrl.searchParams.get("id");
    const id = Number(idParam);
    if (!id || Number.isNaN(id)) {
      return NextResponse.json({ error: "Valid preset id required" }, { status: 400 });
    }
    await db.delete(dspPresets).where(eq(dspPresets.id, id));
    return NextResponse.json({ deleted: true });
  } catch (err) {
    console.error("Failed to delete preset:", err);
    return NextResponse.json({ error: "Failed to delete preset" }, { status: 500 });
  }
}
