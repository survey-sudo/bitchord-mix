import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  deviceBenchmarks,
  dspPresets,
  tracks,
  transitionEvaluations,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { asc, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();

    const [trackRows, presetRows, evalRows, benchRows] = await Promise.all([
      db.select().from(tracks).orderBy(asc(tracks.id)),
      db.select().from(dspPresets).orderBy(asc(dspPresets.id)),
      db
        .select()
        .from(transitionEvaluations)
        .orderBy(desc(transitionEvaluations.createdAt))
        .limit(25),
      db
        .select()
        .from(deviceBenchmarks)
        .orderBy(asc(deviceBenchmarks.modelInferenceMs)),
    ]);

    return NextResponse.json({
      tracks: trackRows,
      presets: presetRows,
      evaluations: evalRows,
      benchmarks: benchRows,
    });
  } catch (err) {
    console.error("Bootstrap API failed:", err);
    return NextResponse.json(
      { error: "Failed to bootstrap AutoMix studio state" },
      { status: 500 }
    );
  }
}
