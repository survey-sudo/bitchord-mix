import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { tracks } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const rawTitle = String(body.title ?? "Uploaded Track").trim();
    const slug = `${rawTitle
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")}-${Date.now().toString(36)}`;

    const [created] = await db
      .insert(tracks)
      .values({
        slug,
        title: rawTitle,
        artist: String(body.artist ?? "Local Device Storage"),
        genre: String(body.genre ?? "Uncurated Local Audio"),
        bpm: Number(body.bpm ?? 120),
        camelotKey: String(body.camelotKey ?? "8A"),
        musicalKey: String(body.musicalKey ?? "A Minor"),
        durationSec: Number(body.durationSec ?? 36),
        isCurated: false,
        introEndSec: Number(body.introEndSec ?? 7.5),
        outroStartSec: Number(body.outroStartSec ?? 26.0),
        vocalOutroDensity: Number(body.vocalOutroDensity ?? 0.35),
        vocalIntroDensity: Number(body.vocalIntroDensity ?? 0.35),
        energy: Number(body.energy ?? 0.78),
        hasSilenceTail: Boolean(body.hasSilenceTail ?? false),
        synthPreset: String(body.synthPreset ?? "deep_house_8a"),
        coverGradient: String(
          body.coverGradient ?? "from-emerald-500 via-cyan-600 to-slate-900"
        ),
      })
      .returning();

    return NextResponse.json({ track: created }, { status: 201 });
  } catch (err) {
    console.error("Failed to persist analyzed track:", err);
    return NextResponse.json(
      { error: "Failed to persist analyzed track" },
      { status: 500 }
    );
  }
}
