import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { transitionEvaluations } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select()
      .from(transitionEvaluations)
      .orderBy(desc(transitionEvaluations.createdAt))
      .limit(30);
    return NextResponse.json({ evaluations: rows });
  } catch (err) {
    console.error("Failed to query evaluations:", err);
    return NextResponse.json({ error: "Failed to query evaluations" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [created] = await db
      .insert(transitionEvaluations)
      .values({
        fromTrackTitle: String(body.fromTrackTitle ?? "Track A"),
        toTrackTitle: String(body.toTrackTitle ?? "Track B"),
        isNonCuratedPair: Boolean(body.isNonCuratedPair ?? false),
        fromBpm: Number(body.fromBpm ?? 120),
        toBpm: Number(body.toBpm ?? 120),
        fromCamelot: String(body.fromCamelot ?? "8A"),
        toCamelot: String(body.toCamelot ?? "8A"),
        strategyUsed: String(body.strategyUsed ?? "PHRASE_BEATMATCH_BASS_SWAP"),
        stretchRatioPct: Number(body.stretchRatioPct ?? 0),
        mixDurationSec: Number(body.mixDurationSec ?? 8),
        cueOutSec: Number(body.cueOutSec ?? 24),
        cueInSec: Number(body.cueInSec ?? 0),
        androidAutoMixScore: Math.max(
          0,
          Math.min(100, Math.round(Number(body.androidAutoMixScore ?? 92)))
        ),
        appleBaselineScore: Math.max(
          0,
          Math.min(100, Math.round(Number(body.appleBaselineScore ?? 75)))
        ),
        crossfadeBaselineScore: Math.max(
          0,
          Math.min(100, Math.round(Number(body.crossfadeBaselineScore ?? 50)))
        ),
        notes: String(body.notes ?? "Evaluated in Android AutoMix Workbench."),
      })
      .returning();

    return NextResponse.json({ evaluation: created }, { status: 201 });
  } catch (err) {
    console.error("Failed to create evaluation:", err);
    return NextResponse.json({ error: "Failed to create evaluation" }, { status: 500 });
  }
}
