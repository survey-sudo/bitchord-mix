import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { deviceBenchmarks } from "@/db/schema";
import { asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select()
      .from(deviceBenchmarks)
      .orderBy(asc(deviceBenchmarks.modelInferenceMs));
    return NextResponse.json({ benchmarks: rows });
  } catch (err) {
    console.error("Failed to fetch benchmarks:", err);
    return NextResponse.json({ error: "Failed to fetch benchmarks" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [created] = await db
      .insert(deviceBenchmarks)
      .values({
        deviceName: String(body.deviceName ?? "Custom Android Device"),
        socTier: String(body.socTier ?? "Upper-Mid GPU"),
        delegateUsed: String(body.delegateUsed ?? "LiteRT NNAPI INT8"),
        decode30sMs: Number(body.decode30sMs ?? 145.0),
        modelInferenceMs: Number(body.modelInferenceMs ?? 22.4),
        dspCpuLoadPct: Number(body.dspCpuLoadPct ?? 3.4),
        peakRamMb: Number(body.peakRamMb ?? 13.5),
        batteryDrainPctPerHr: Number(body.batteryDrainPctPerHr ?? 1.5),
        nonCuratedPassRatePct: Number(body.nonCuratedPassRatePct ?? 93.8),
      })
      .returning();

    return NextResponse.json({ benchmark: created }, { status: 201 });
  } catch (err) {
    console.error("Failed to create benchmark:", err);
    return NextResponse.json({ error: "Failed to create benchmark" }, { status: 500 });
  }
}
