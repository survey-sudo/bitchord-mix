import React from "react";
import { db } from "@/db";
import {
  deviceBenchmarks,
  dspPresets,
  tracks,
  transitionEvaluations,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { asc, desc } from "drizzle-orm";
import { AutoMixStudioClient } from "@/components/AutoMixStudioClient";
import { DspEngineConfig, TrackItem } from "@/lib/automix-types";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureSeeded();

  const [trackRows, presetRows, evalRows, benchRows] = await Promise.all([
    db.select().from(tracks).orderBy(asc(tracks.id)),
    db.select().from(dspPresets).orderBy(asc(dspPresets.id)),
    db
      .select()
      .from(transitionEvaluations)
      .orderBy(desc(transitionEvaluations.createdAt))
      .limit(25),
    db
      .select()
      .from(deviceBenchmarks)
      .orderBy(asc(deviceBenchmarks.modelInferenceMs)),
  ]);

  const mappedTracks: TrackItem[] = trackRows.map((t) => ({
    id: t.id,
    slug: t.slug,
    title: t.title,
    artist: t.artist,
    genre: t.genre,
    bpm: t.bpm,
    camelotKey: t.camelotKey,
    musicalKey: t.musicalKey,
    durationSec: t.durationSec,
    isCurated: t.isCurated,
    introEndSec: t.introEndSec,
    outroStartSec: t.outroStartSec,
    vocalOutroDensity: t.vocalOutroDensity,
    vocalIntroDensity: t.vocalIntroDensity,
    energy: t.energy,
    hasSilenceTail: t.hasSilenceTail,
    synthPreset: t.synthPreset,
    coverGradient: t.coverGradient,
  }));

  const mappedPresets: DspEngineConfig[] = presetRows.map((p) => ({
    id: p.id,
    name: p.name,
    description: p.description,
    maxStretchPct: p.maxStretchPct,
    defaultMixBars: p.defaultMixBars,
    bassSwapSharpness: p.bassSwapSharpness,
    vocalDuckDb: p.vocalDuckDb,
    harmonicWeight: p.harmonicWeight,
    enableHalfDoubleLock: p.enableHalfDoubleLock,
    enableEchoFreezeFallback: p.enableEchoFreezeFallback,
    silenceGateDb: p.silenceGateDb,
    npuDelegate: p.npuDelegate,
    isBuiltIn: p.isBuiltIn,
  }));

  return (
    <AutoMixStudioClient
      initialTracks={mappedTracks}
      initialPresets={mappedPresets}
      initialEvaluations={evalRows}
      initialBenchmarks={benchRows}
    />
  );
}
