"use client";

import React, { useRef } from "react";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Sparkles,
  Upload,
  Disc3,
  Radio,
  Zap,
  Music2,
  Volume2,
  Wifi,
  BatteryCharging,
} from "lucide-react";
import {
  DspEngineConfig,
  LiveMixTelemetry,
  TrackItem,
} from "@/lib/automix-types";
import { planAutoMixTransition } from "@/lib/automix-planner";

interface AndroidPlayerMockupProps {
  queue: TrackItem[];
  telemetry: LiveMixTelemetry;
  config: DspEngineConfig;
  isAnalyzingUpload: boolean;
  uploadNotice: string | null;
  onTogglePlay: () => void;
  onSkipPrev: () => void;
  onSkipNext: () => void;
  onSeek: (sec: number) => void;
  onTriggerSweetSpot: () => void;
  onToggleAutoMix: (enabled: boolean) => void;
  onSelectTrackIndex: (idx: number) => void;
  onUploadFiles: (files: FileList) => void;
}

function formatTime(sec: number): string {
  const safe = Math.max(0, Math.floor(sec));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function AndroidPlayerMockup({
  queue,
  telemetry,
  config,
  isAnalyzingUpload,
  uploadNotice,
  onTogglePlay,
  onSkipPrev,
  onSkipNext,
  onSeek,
  onTriggerSweetSpot,
  onToggleAutoMix,
  onSelectTrackIndex,
  onUploadFiles,
}: AndroidPlayerMockupProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const trackA = queue[telemetry.activeTrackIndex] ?? queue[0];
  const trackB = queue[telemetry.nextTrackIndex] ?? queue[1] ?? queue[0];
  const plan = telemetry.activePlan;

  const duration = Math.max(1, telemetry.deckADurationSec || trackA?.durationSec || 38);
  const progressPct = Math.min(100, Math.max(0, (telemetry.deckAPositionSec / duration) * 100));
  const cueOutPct =
    plan && telemetry.autoMixEnabled
      ? Math.min(96, Math.max(20, (plan.cueOutSec / duration) * 100))
      : 82;

  if (!trackA) return null;

  return (
    <div className="flex flex-col items-center">
      {/* Flagship Android Phone Chassis */}
      <div className="relative w-full max-w-[405px] rounded-[2.6rem] border border-white/15 bg-[#0b0f19] p-3.5 shadow-[0_25px_80px_-15px_rgba(6,182,212,0.28)]">
        {/* Ambient Dynamic Album Glow */}
        <div
          className={`pointer-events-none absolute inset-4 rounded-[2.2rem] bg-gradient-to-br ${
            telemetry.isMixing && trackB ? trackB.coverGradient : trackA.coverGradient
          } opacity-20 blur-2xl transition-all duration-700`}
        />

        <div className="relative z-10 flex flex-col overflow-hidden rounded-[2.1rem] border border-white/10 bg-[#0d121f]/95 px-4 pt-3 pb-4">
          {/* Android 16 Status Bar */}
          <div className="mb-3 flex items-center justify-between px-1 text-[11px] font-medium text-slate-400">
            <div className="flex items-center gap-1.5">
              <span>9:41</span>
              <span className="rounded bg-cyan-500/15 px-1.5 py-0.5 text-[9px] font-semibold tracking-wider text-cyan-300">
                LiteRT NPU
              </span>
            </div>
            {/* Camera Punch-hole */}
            <div className="h-2.5 w-2.5 rounded-full bg-black ring-1 ring-white/15" />
            <div className="flex items-center gap-1.5 text-slate-400">
              <Wifi className="h-3 w-3" />
              <span>5G</span>
              <BatteryCharging className="h-3.5 w-3.5 text-emerald-400" />
            </div>
          </div>

          {/* Top Dynamic AutoMix Status Pill (Apple Music iOS 26 inspired + Android On-Device Telemetry) */}
          <div className="mb-3 flex items-center justify-between gap-2">
            {telemetry.isMixing ? (
              <div className="automix-glow-pill flex w-full items-center justify-between rounded-full border border-cyan-400/50 bg-gradient-to-r from-cyan-500/25 via-fuchsia-500/20 to-indigo-500/25 px-3 py-1.5 shadow-lg shadow-cyan-500/15">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-3.5 w-3.5 text-cyan-300" />
                  <span className="text-xs font-semibold tracking-wide text-white">
                    {telemetry.autoMixEnabled ? "AutoMix • Mixing" : "Standard Crossfade"}
                  </span>
                </div>
                <span className="font-mono text-[11px] font-semibold text-cyan-200">
                  {telemetry.autoMixEnabled && plan
                    ? `${plan.strategyShortBadge} • ${Math.round(telemetry.mixProgress * 100)}%`
                    : `${Math.round(telemetry.mixProgress * 100)}%`}
                </span>
              </div>
            ) : (
              <div className="flex w-full items-center justify-between rounded-full border border-white/10 bg-slate-900/80 px-3 py-1.5">
                <div className="flex items-center gap-1.5">
                  <Disc3
                    className={`h-3.5 w-3.5 text-cyan-400 ${
                      telemetry.isPlaying ? "animate-spin" : ""
                    }`}
                  />
                  <span className="text-[11px] font-medium text-slate-300">
                    {telemetry.autoMixEnabled
                      ? "On-Device AutoMix Armed"
                      : "AutoMix Bypassed (Crossfade)"}
                  </span>
                </div>
                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                    trackA.isCurated
                      ? "bg-emerald-500/15 text-emerald-300"
                      : "bg-amber-500/20 text-amber-300"
                  }`}
                >
                  {trackA.isCurated ? "CURATED" : "NON-CURATED"}
                </span>
              </div>
            )}
          </div>

          {/* Dual Morphing Album Artwork Stage */}
          <div className="relative mb-3.5 h-52 w-full overflow-hidden rounded-2xl border border-white/10 shadow-xl">
            {/* Outgoing Track A Artwork */}
            <div
              style={{
                opacity: telemetry.isMixing ? Math.max(0.18, 1 - telemetry.mixProgress * 0.85) : 1,
                transform: telemetry.isMixing
                  ? `scale(${1 - telemetry.mixProgress * 0.06})`
                  : "scale(1)",
              }}
              className={`absolute inset-0 bg-gradient-to-br ${trackA.coverGradient} p-4 transition-transform duration-150 flex flex-col justify-between`}
            >
              <div className="flex items-center justify-between">
                <span className="rounded-lg bg-black/45 px-2.5 py-1 font-mono text-[11px] font-semibold text-white backdrop-blur-md">
                  {telemetry.deckACurrentBpm.toFixed(1)} BPM • {trackA.camelotKey}
                </span>
                {trackA.isLocalUpload && (
                  <span className="rounded-lg bg-cyan-400/25 px-2 py-0.5 text-[10px] font-bold text-cyan-100 backdrop-blur-md">
                    LOCAL AUDIO
                  </span>
                )}
              </div>

              <div className="space-y-0.5">
                <p className="text-[10px] font-semibold tracking-widest text-white/75 uppercase">
                  {trackA.genre} • {trackA.musicalKey}
                </p>
                <h2 className="truncate text-xl font-bold tracking-tight text-white drop-shadow">
                  {trackA.title}
                </h2>
                <p className="truncate text-xs font-medium text-white/85">{trackA.artist}</p>
              </div>
            </div>

            {/* Incoming Track B Morph Overlay during AutoMix */}
            {telemetry.isMixing && trackB && (
              <div
                style={{ opacity: Math.min(1, telemetry.mixProgress * 1.08) }}
                className={`absolute inset-0 bg-gradient-to-tl ${trackB.coverGradient} p-4 flex flex-col justify-between`}
              >
                <div className="flex items-center justify-between">
                  <span className="rounded-lg bg-black/55 px-2.5 py-1 font-mono text-[11px] font-semibold text-cyan-200 backdrop-blur-md">
                    INCOMING • {telemetry.deckBCurrentBpm.toFixed(1)} BPM • {trackB.camelotKey}
                  </span>
                  <span className="rounded-lg bg-white/20 px-2 py-0.5 text-[10px] font-bold text-white backdrop-blur-md">
                    DECK B LOCK
                  </span>
                </div>
                <div className="space-y-0.5">
                  <p className="text-[10px] font-semibold tracking-widest text-cyan-100 uppercase">
                    Blending Into → {trackB.genre}
                  </p>
                  <h2 className="truncate text-xl font-bold tracking-tight text-white drop-shadow">
                    {trackB.title}
                  </h2>
                  <p className="truncate text-xs font-medium text-white/90">{trackB.artist}</p>
                </div>
              </div>
            )}

            {/* 4-Beat Downbeat Phase Lock Strobe Strip at Bottom of Artwork */}
            <div className="absolute right-3 bottom-2.5 left-3 flex items-center justify-between rounded-xl bg-black/55 px-3 py-1.5 backdrop-blur-md">
              <div className="flex items-center gap-1.5">
                {[0, 1, 2, 3].map((b) => {
                  const active = telemetry.isPlaying && telemetry.barBeatIndex === b;
                  return (
                    <span
                      key={b}
                      className={`h-2 w-5 rounded-full transition-all duration-75 ${
                        active
                          ? b === 0
                            ? "bg-cyan-300 shadow-[0_0_10px_#67e8f9]"
                            : "bg-fuchsia-400 shadow-[0_0_8px_#e879f9]"
                          : "bg-white/20"
                      }`}
                    />
                  );
                })}
              </div>
              <span className="font-mono text-[10px] text-slate-200">
                {telemetry.isMixing && telemetry.autoMixEnabled
                  ? `Stretch ${(telemetry.deckARate * 100 - 100 >= 0 ? "+" : "") + (telemetry.deckARate * 100 - 100).toFixed(1)}%`
                  : `Sweet Spot @ ${formatTime(plan?.cueOutSec ?? trackA.outroStartSec)}`}
              </span>
            </div>
          </div>

          {/* Interactive Timeline with Highlighted AutoMix Sweet-Spot Region */}
          <div className="mb-3 space-y-1.5">
            <div
              className="group relative h-3 w-full cursor-pointer rounded-full bg-slate-800/90 p-0.5"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                onSeek(ratio * duration);
              }}
              title="Click anywhere to seek Deck A"
            >
              {/* Sweet Spot AutoMix Zone Highlight */}
              {telemetry.autoMixEnabled && (
                <div
                  style={{ left: `${cueOutPct}%`, width: `${100 - cueOutPct}%` }}
                  className="absolute top-0 bottom-0 rounded-r-full bg-cyan-400/25 ring-1 ring-cyan-400/40"
                />
              )}
              {/* Elapsed Progress Fill */}
              <div
                style={{ width: `${progressPct}%` }}
                className="relative h-full rounded-full bg-gradient-to-r from-cyan-400 via-sky-400 to-fuchsia-400"
              >
                <span className="absolute -top-0.5 right-0 h-3 w-3 translate-x-1/2 rounded-full bg-white shadow" />
              </div>
            </div>

            <div className="flex items-center justify-between font-mono text-[11px] text-slate-400">
              <span>{formatTime(telemetry.deckAPositionSec)}</span>
              <span className="text-[10px] text-cyan-300/90">
                {telemetry.autoMixEnabled && plan
                  ? `Mix Cue ${formatTime(plan.cueOutSec)} (${plan.mixBars} bars)`
                  : "Standard 6s Tail Fade"}
              </span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Main Transport Controls + One-Click Sweet-Spot Preview */}
          <div className="mb-3 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={onSkipPrev}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-slate-900 text-slate-200 transition hover:border-cyan-400/40 hover:text-white"
              aria-label="Previous Track"
            >
              <SkipBack className="h-4 w-4" />
            </button>

            <button
              type="button"
              onClick={onTogglePlay}
              className="flex h-13 w-13 items-center justify-center rounded-full bg-gradient-to-tr from-cyan-400 to-sky-300 text-slate-950 shadow-lg shadow-cyan-500/30 transition hover:scale-105 active:scale-95"
              aria-label={telemetry.isPlaying ? "Pause" : "Play"}
            >
              {telemetry.isPlaying ? (
                <Pause className="h-6 w-6 fill-current" />
              ) : (
                <Play className="h-6 w-6 translate-x-0.5 fill-current" />
              )}
            </button>

            <button
              type="button"
              onClick={onSkipNext}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-slate-900 text-slate-200 transition hover:border-cyan-400/40 hover:text-white"
              aria-label="Next Track"
            >
              <SkipForward className="h-4 w-4" />
            </button>

            {/* Instant DJ Transition Audition CTA */}
            <button
              type="button"
              onClick={onTriggerSweetSpot}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-cyan-400/40 bg-cyan-500/15 px-3 py-2.5 text-xs font-semibold text-cyan-200 transition hover:bg-cyan-500/25 active:scale-[0.98]"
            >
              <Zap className="h-3.5 w-3.5 text-cyan-300" />
              <span>Audition Mix (T-3s)</span>
            </button>
          </div>

          {/* AutoMix AI vs Naive Crossfade Live A/B Switch */}
          <div className="mb-3 grid grid-cols-2 gap-1.5 rounded-xl border border-white/10 bg-slate-950/90 p-1">
            <button
              type="button"
              onClick={() => onToggleAutoMix(true)}
              className={`flex items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs font-semibold transition ${
                telemetry.autoMixEnabled
                  ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>AutoMix AI (On)</span>
            </button>
            <button
              type="button"
              onClick={() => onToggleAutoMix(false)}
              className={`flex items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs font-semibold transition ${
                !telemetry.autoMixEnabled
                  ? "bg-rose-500/80 text-white shadow"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Radio className="h-3.5 w-3.5" />
              <span>Naive Crossfade</span>
            </button>
          </div>

          {/* Local Uncurated File Upload Bar */}
          <div className="mb-2.5">
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  onUploadFiles(e.target.files);
                  e.target.value = "";
                }
              }}
            />
            <button
              type="button"
              disabled={isAnalyzingUpload}
              onClick={() => fileInputRef.current?.click()}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-white/20 bg-white/[0.03] px-3 py-2 text-xs font-medium text-slate-300 transition hover:border-cyan-400/50 hover:bg-cyan-500/10 hover:text-cyan-200 disabled:opacity-50"
            >
              <Upload className="h-3.5 w-3.5 text-cyan-400" />
              <span>
                {isAnalyzingUpload
                  ? "Running On-Device PCM Analysis (BPM / Key / Sweet Spot)..."
                  : "Drop / Upload Local MP3, WAV, FLAC (Non-Curated Test)"}
              </span>
            </button>
            {uploadNotice && (
              <p className="mt-1.5 rounded-lg bg-emerald-500/15 px-2.5 py-1 text-[11px] text-emerald-300">
                {uploadNotice}
              </p>
            )}
          </div>

          {/* Up Next Queue with Planned Transition Strategy Chips */}
          <div className="flex items-center justify-between pb-1.5 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
            <span className="flex items-center gap-1">
              <Music2 className="h-3 w-3 text-cyan-400" />
              Play Queue ({queue.length} Tracks)
            </span>
            <span className="flex items-center gap-1 text-[10px] text-slate-500">
              <Volume2 className="h-3 w-3" /> WebAudio DSP
            </span>
          </div>

          <div className="max-h-52 space-y-1.5 overflow-y-auto pr-1">
            {queue.map((item, idx) => {
              const isCurrent = idx === telemetry.activeTrackIndex;
              const isNext = idx === telemetry.nextTrackIndex && telemetry.isMixing;
              const nextItem = queue[(idx + 1) % queue.length];
              const pairPlan =
                nextItem && queue.length > 1
                  ? planAutoMixTransition(item, nextItem, config)
                  : null;

              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectTrackIndex(idx)}
                  className={`w-full rounded-xl border p-2 text-left transition ${
                    isCurrent
                      ? "border-cyan-400/50 bg-cyan-500/15"
                      : isNext
                      ? "border-fuchsia-400/50 bg-fuchsia-500/15"
                      : "border-white/5 bg-slate-900/65 hover:border-white/15 hover:bg-slate-900"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-xs font-semibold text-white">
                          {idx + 1}. {item.title}
                        </span>
                        <span
                          className={`shrink-0 rounded px-1.5 py-0.2 text-[9px] font-bold ${
                            item.isCurated
                              ? "bg-emerald-500/20 text-emerald-300"
                              : "bg-amber-500/20 text-amber-300"
                          }`}
                        >
                          {item.isCurated ? "CURATED" : "NON-CURATED"}
                        </span>
                      </div>
                      <p className="truncate text-[11px] text-slate-400">
                        {item.artist} • {item.genre}
                      </p>
                    </div>
                    <div className="shrink-0 text-right font-mono text-[10px]">
                      <div className="font-semibold text-slate-200">{item.bpm} BPM</div>
                      <div className="text-cyan-300">{item.camelotKey}</div>
                    </div>
                  </div>
                  {pairPlan && (
                    <div className="mt-1.5 flex items-center justify-between border-t border-white/5 pt-1 text-[10px] text-slate-400">
                      <span className="truncate">
                        → Next:{" "}
                        <strong className="font-medium text-cyan-300">
                          {pairPlan.strategyShortBadge}
                        </strong>{" "}
                        ({pairPlan.tempoRatioMode})
                      </span>
                      <span className="font-mono text-emerald-300">
                        Score {pairPlan.androidAutoMixScore}
                      </span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
