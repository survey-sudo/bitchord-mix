"use client";

import React, { useState } from "react";
import {
  Activity,
  Sliders,
  Save,
  Trash2,
  Cpu,
  CheckCircle2,
  Waves,
  Gauge,
} from "lucide-react";
import {
  DspEngineConfig,
  LiveMixTelemetry,
  TrackItem,
} from "@/lib/automix-types";

interface DualDeckVisualizerProps {
  trackA: TrackItem | undefined;
  trackB: TrackItem | undefined;
  peaksA: number[];
  peaksB: number[];
  telemetry: LiveMixTelemetry;
  config: DspEngineConfig;
  presets: DspEngineConfig[];
  onChangeConfig: (next: DspEngineConfig) => void;
  onSelectPreset: (preset: DspEngineConfig) => void;
  onSavePreset: (name: string, description: string) => Promise<void>;
  onDeletePreset: (id: number) => Promise<void>;
}

export function DualDeckVisualizer({
  trackA,
  trackB,
  peaksA,
  peaksB,
  telemetry,
  config,
  presets,
  onChangeConfig,
  onSelectPreset,
  onSavePreset,
  onDeletePreset,
}: DualDeckVisualizerProps) {
  const [newPresetName, setNewPresetName] = useState("");
  const [newPresetDesc, setNewPresetDesc] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const plan = telemetry.activePlan;

  const durA = Math.max(1, trackA?.durationSec ?? 38);
  const durB = Math.max(1, trackB?.durationSec ?? 38);
  const posAPct = Math.min(100, Math.max(0, (telemetry.deckAPositionSec / durA) * 100));
  const posBPct = Math.min(100, Math.max(0, (telemetry.deckBPositionSec / durB) * 100));

  const cueOutStartPct = plan ? Math.min(95, (plan.cueOutSec / durA) * 100) : 75;
  const cueOutWidthPct = plan
    ? Math.min(100 - cueOutStartPct, (plan.mixDurationSec / durA) * 100)
    : 20;

  const cueInStartPct = plan ? Math.min(80, (plan.cueInSec / durB) * 100) : 0;
  const cueInWidthPct = plan
    ? Math.min(100 - cueInStartPct, (plan.mixDurationSec / durB) * 100)
    : 20;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPresetName.trim()) return;
    setIsSaving(true);
    try {
      await onSavePreset(newPresetName.trim(), newPresetDesc.trim());
      setNewPresetName("");
      setNewPresetDesc("");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Dual-Deck Waveform & Beat-Grid Overlap Scope */}
      <div className="rounded-2xl border border-white/10 bg-[#0d1322]/90 p-5 shadow-xl">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Waves className="h-4 w-4 text-cyan-400" />
              <h3 className="text-sm font-bold tracking-wide text-white uppercase">
                Dual-Deck Lookahead RingBuffer & Sweet-Spot Scope
              </h3>
            </div>
            <p className="mt-0.5 text-xs text-slate-400">
              Real-time WSOLA time-stretch rate, phrase cue alignment, and 24dB/oct LR4 Sub-Bass Crossover
            </p>
          </div>

          {plan && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-lg border border-cyan-400/30 bg-cyan-500/15 px-2.5 py-1 font-mono text-xs font-semibold text-cyan-200">
                {plan.strategyLabel}
              </span>
              <span className="rounded-lg border border-emerald-400/30 bg-emerald-500/15 px-2.5 py-1 font-mono text-xs font-semibold text-emerald-300">
                AutoMix {plan.androidAutoMixScore}/100
              </span>
            </div>
          )}
        </div>

        {/* DECK A WAVEFORM */}
        <div className="mb-3 rounded-xl border border-white/10 bg-slate-950/90 p-3">
          <div className="mb-2 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="rounded bg-cyan-500/20 px-2 py-0.5 font-mono text-[10px] font-bold text-cyan-300">
                DECK A • OUTGOING
              </span>
              <span className="font-semibold text-white">
                {trackA?.title ?? "No Track"}
              </span>
              {trackA && !trackA.isCurated && (
                <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-semibold text-amber-300">
                  Non-Curated
                </span>
              )}
            </div>
            <div className="font-mono text-[11px] text-slate-300">
              Rate <strong className="text-cyan-300">{telemetry.deckARate.toFixed(3)}x</strong> •{" "}
              {telemetry.deckACurrentBpm.toFixed(1)} BPM • Gain{" "}
              {Math.round(telemetry.deckAGain * 100)}%
            </div>
          </div>

          <div className="relative flex h-16 items-center gap-[2px] overflow-hidden rounded-lg bg-slate-900/80 px-1">
            {/* Highlighted Cue-Out Mix Region */}
            {telemetry.autoMixEnabled && (
              <div
                style={{ left: `${cueOutStartPct}%`, width: `${cueOutWidthPct}%` }}
                className="pointer-events-none absolute top-0 bottom-0 border-l-2 border-cyan-400 bg-cyan-500/15"
              >
                <span className="absolute top-1 left-1.5 rounded bg-cyan-950/90 px-1.5 py-0.5 font-mono text-[9px] font-bold text-cyan-300">
                  CUE-OUT {plan?.cueOutSec.toFixed(1)}s
                </span>
              </div>
            )}

            {peaksA.map((pk, idx) => {
              const pct = (idx / peaksA.length) * 100;
              const passed = pct <= posAPct;
              return (
                <div
                  key={idx}
                  style={{ height: `${Math.max(10, pk * 92)}%` }}
                  className={`flex-1 rounded-full transition-colors ${
                    passed ? "bg-cyan-400" : "bg-slate-600/60"
                  }`}
                />
              );
            })}

            {/* Live Playhead */}
            <div
              style={{ left: `${posAPct}%` }}
              className="pointer-events-none absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_8px_#fff]"
            />
          </div>
        </div>

        {/* DECK B WAVEFORM */}
        <div className="rounded-xl border border-white/10 bg-slate-950/90 p-3">
          <div className="mb-2 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="rounded bg-fuchsia-500/20 px-2 py-0.5 font-mono text-[10px] font-bold text-fuchsia-300">
                DECK B • INCOMING LOOKAHEAD
              </span>
              <span className="font-semibold text-white">
                {trackB?.title ?? "No Track"}
              </span>
              {trackB && !trackB.isCurated && (
                <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-semibold text-amber-300">
                  Non-Curated
                </span>
              )}
            </div>
            <div className="font-mono text-[11px] text-slate-300">
              Rate <strong className="text-fuchsia-300">{telemetry.deckBRate.toFixed(3)}x</strong> •{" "}
              {telemetry.deckBCurrentBpm.toFixed(1)} BPM • Gain{" "}
              {Math.round(telemetry.deckBGain * 100)}%
            </div>
          </div>

          <div className="relative flex h-16 items-center gap-[2px] overflow-hidden rounded-lg bg-slate-900/80 px-1">
            {/* Highlighted Cue-In Mix Region */}
            {telemetry.autoMixEnabled && (
              <div
                style={{ left: `${cueInStartPct}%`, width: `${cueInWidthPct}%` }}
                className="pointer-events-none absolute top-0 bottom-0 border-l-2 border-fuchsia-400 bg-fuchsia-500/15"
              >
                <span className="absolute top-1 left-1.5 rounded bg-fuchsia-950/90 px-1.5 py-0.5 font-mono text-[9px] font-bold text-fuchsia-300">
                  CUE-IN {plan?.cueInSec.toFixed(1)}s
                </span>
              </div>
            )}

            {peaksB.map((pk, idx) => {
              const pct = (idx / peaksB.length) * 100;
              const active = telemetry.isMixing && pct <= posBPct;
              return (
                <div
                  key={idx}
                  style={{ height: `${Math.max(10, pk * 92)}%` }}
                  className={`flex-1 rounded-full transition-colors ${
                    active ? "bg-fuchsia-400" : "bg-slate-700/60"
                  }`}
                />
              );
            })}

            {telemetry.isMixing && (
              <div
                style={{ left: `${posBPct}%` }}
                className="pointer-events-none absolute top-0 bottom-0 w-0.5 bg-fuchsia-200 shadow-[0_0_8px_#f5d0fe]"
              />
            )}
          </div>
        </div>

        {/* Live 3-Band Isolator EQ + Filter Wash Telemetry Meters */}
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="rounded-xl border border-white/10 bg-slate-900/75 p-3">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Deck A Sub (185Hz)</span>
              <span className="font-mono font-semibold text-cyan-300">
                {telemetry.deckALowDb.toFixed(1)} dB
              </span>
            </div>
            <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                style={{
                  width: `${Math.max(4, ((24 + telemetry.deckALowDb) / 24) * 100)}%`,
                }}
                className="h-full rounded-full bg-cyan-400 transition-all duration-75"
              />
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-slate-900/75 p-3">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Deck B Sub (185Hz)</span>
              <span className="font-mono font-semibold text-fuchsia-300">
                {telemetry.deckBLowDb.toFixed(1)} dB
              </span>
            </div>
            <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                style={{
                  width: `${Math.max(4, ((24 + telemetry.deckBLowDb) / 24) * 100)}%`,
                }}
                className="h-full rounded-full bg-fuchsia-400 transition-all duration-75"
              />
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-slate-900/75 p-3">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Vocal Scoop (1.2kHz)</span>
              <span className="font-mono font-semibold text-amber-300">
                {telemetry.deckAMidDb.toFixed(1)} dB
              </span>
            </div>
            <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                style={{
                  width: `${Math.max(6, Math.min(100, (Math.abs(telemetry.deckAMidDb) / 14) * 100))}%`,
                }}
                className="h-full rounded-full bg-amber-400 transition-all duration-75"
              />
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-slate-900/75 p-3">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>HPF Wash / Echo</span>
              <span className="font-mono font-semibold text-emerald-300">
                {telemetry.deckAHpfHz}Hz • {Math.round(telemetry.echoWetMix * 100)}%
              </span>
            </div>
            <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                style={{
                  width: `${Math.max(
                    6,
                    Math.min(100, (telemetry.deckAHpfHz / 1900) * 100 + telemetry.echoWetMix * 50)
                  )}%`,
                }}
                className="h-full rounded-full bg-emerald-400 transition-all duration-75"
              />
            </div>
          </div>
        </div>

        {/* Active On-Device Model Decision Bullets */}
        {plan && (
          <div className="mt-4 rounded-xl border border-cyan-500/20 bg-cyan-950/20 p-3.5">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-xs font-semibold text-cyan-200">
                <Activity className="h-3.5 w-3.5 text-cyan-400" />
                On-Device TransitionNet Decision Log ({trackA?.title} → {trackB?.title})
              </span>
              <span className="font-mono text-[11px] text-slate-300">
                {plan.harmonicRelation} • Vocal Risk {Math.round(plan.vocalClashRisk * 100)}%
              </span>
            </div>
            <ul className="space-y-1 text-xs text-slate-300">
              {plan.reasoningBullets.map((b, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-cyan-400" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Real-Time DSP & On-Device Model Parameter Workbench + PostgreSQL Presets */}
      <div className="rounded-2xl border border-white/10 bg-[#0d1322]/90 p-5 shadow-xl">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sliders className="h-4 w-4 text-cyan-400" />
            <h3 className="text-sm font-bold tracking-wide text-white uppercase">
              Android AutoMix DSP & On-Device Solver Tuning
            </h3>
          </div>
          <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-slate-900 px-3 py-1 font-mono text-[11px] text-slate-300">
            <Cpu className="h-3.5 w-3.5 text-cyan-400" />
            Delegate: {config.npuDelegate}
          </span>
        </div>

        {/* PostgreSQL Preset Selector Pills */}
        <div className="mb-5 flex flex-wrap gap-2">
          {presets.map((p) => {
            const active = config.name === p.name;
            return (
              <div
                key={p.id ?? p.name}
                className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-medium transition ${
                  active
                    ? "border-cyan-400 bg-cyan-500/20 text-white"
                    : "border-white/10 bg-slate-900/75 text-slate-300 hover:border-white/25"
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelectPreset(p)}
                  className="text-left"
                >
                  {p.name}
                </button>
                {!p.isBuiltIn && p.id && (
                  <button
                    type="button"
                    onClick={() => void onDeletePreset(p.id!)}
                    className="ml-1 rounded p-0.5 text-slate-400 hover:bg-rose-500/20 hover:text-rose-300"
                    title="Delete custom preset"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Interactive Parameter Sliders */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div className="rounded-xl border border-white/5 bg-slate-950/75 p-3">
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-slate-300">Max WSOLA Stretch Ceiling</span>
              <span className="font-mono font-semibold text-cyan-300">
                ±{config.maxStretchPct.toFixed(1)}%
              </span>
            </div>
            <input
              type="range"
              min={4}
              max={18}
              step={0.5}
              value={config.maxStretchPct}
              onChange={(e) =>
                onChangeConfig({ ...config, maxStretchPct: Number(e.target.value) })
              }
              className="w-full"
            />
            <p className="mt-1 text-[11px] text-slate-500">
              Above ceiling triggers 2:1 Lock or Dub Echo Freeze
            </p>
          </div>

          <div className="rounded-xl border border-white/5 bg-slate-950/75 p-3">
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-slate-300">Target Phrase Blend Window</span>
              <span className="font-mono font-semibold text-cyan-300">
                {config.defaultMixBars} Bars
              </span>
            </div>
            <div className="mt-1.5 grid grid-cols-3 gap-1.5">
              {[4, 8, 16].map((bars) => (
                <button
                  key={bars}
                  type="button"
                  onClick={() => onChangeConfig({ ...config, defaultMixBars: bars })}
                  className={`rounded-lg py-1 font-mono text-xs font-semibold transition ${
                    config.defaultMixBars === bars
                      ? "bg-cyan-500 text-slate-950"
                      : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                  }`}
                >
                  {bars} Bars
                </button>
              ))}
            </div>
            <p className="mt-1.5 text-[11px] text-slate-500">
              Snaps Cue-Out & Cue-In to 4/4 downbeat bars
            </p>
          </div>

          <div className="rounded-xl border border-white/5 bg-slate-950/75 p-3">
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-slate-300">Vocal Clash Mid-Scoop (1.2kHz)</span>
              <span className="font-mono font-semibold text-amber-300">
                {config.vocalDuckDb.toFixed(1)} dB
              </span>
            </div>
            <input
              type="range"
              min={-14}
              max={0}
              step={0.5}
              value={config.vocalDuckDb}
              onChange={(e) =>
                onChangeConfig({ ...config, vocalDuckDb: Number(e.target.value) })
              }
              className="w-full"
            />
            <p className="mt-1 text-[11px] text-slate-500">
              Carves outgoing lead vocals when incoming singer enters
            </p>
          </div>

          <div className="rounded-xl border border-white/5 bg-slate-950/75 p-3">
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-slate-300">LR4 Sub-Bass Swap Sharpness</span>
              <span className="font-mono font-semibold text-fuchsia-300">
                {Math.round(config.bassSwapSharpness * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0.25}
              max={1.0}
              step={0.05}
              value={config.bassSwapSharpness}
              onChange={(e) =>
                onChangeConfig({ ...config, bassSwapSharpness: Number(e.target.value) })
              }
              className="w-full"
            />
            <p className="mt-1 text-[11px] text-slate-500">
              Controls 185Hz kick/sub handoff slope at midpoint bar
            </p>
          </div>

          <div className="rounded-xl border border-white/5 bg-slate-950/75 p-3">
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-slate-300">Camelot Harmonic Strictness</span>
              <span className="font-mono font-semibold text-emerald-300">
                {Math.round(config.harmonicWeight * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={config.harmonicWeight}
              onChange={(e) =>
                onChangeConfig({ ...config, harmonicWeight: Number(e.target.value) })
              }
              className="w-full"
            />
            <p className="mt-1 text-[11px] text-slate-500">
              Engages HPF tonal mask when key distance ≥ 3.5 steps
            </p>
          </div>

          <div className="flex flex-col justify-between rounded-xl border border-white/5 bg-slate-950/75 p-3">
            <label className="flex cursor-pointer items-center justify-between text-xs text-slate-200">
              <span>2:1 Poly-Tempo Grid Lock</span>
              <input
                type="checkbox"
                checked={config.enableHalfDoubleLock}
                onChange={(e) =>
                  onChangeConfig({ ...config, enableHalfDoubleLock: e.target.checked })
                }
                className="h-4 w-4 accent-cyan-400"
              />
            </label>
            <label className="mt-2 flex cursor-pointer items-center justify-between text-xs text-slate-200">
              <span>Dub Echo Freeze Rescue</span>
              <input
                type="checkbox"
                checked={config.enableEchoFreezeFallback}
                onChange={(e) =>
                  onChangeConfig({
                    ...config,
                    enableEchoFreezeFallback: e.target.checked,
                  })
                }
                className="h-4 w-4 accent-cyan-400"
              />
            </label>
            <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <Gauge className="h-3 w-3 text-cyan-400" />
                NPU Target
              </span>
              <select
                value={config.npuDelegate}
                onChange={(e) =>
                  onChangeConfig({ ...config, npuDelegate: e.target.value })
                }
                className="rounded border border-white/10 bg-slate-900 px-1.5 py-0.5 font-mono text-[10px] text-cyan-200"
              >
                <option value="AUTO_NNAPI_GPU">AUTO_NNAPI_GPU</option>
                <option value="HEXAGON_HTP_INT8">HEXAGON_HTP_INT8</option>
                <option value="TENSOR_TPU_INT8">TENSOR_TPU_INT8</option>
                <option value="XNNPACK_CPU_INT8">XNNPACK_CPU_INT8</option>
              </select>
            </div>
          </div>
        </div>

        {/* Save Custom Preset to PostgreSQL */}
        <form
          onSubmit={handleSave}
          className="mt-4 flex flex-col gap-2 rounded-xl border border-white/10 bg-slate-950/60 p-3 sm:flex-row sm:items-center"
        >
          <input
            type="text"
            placeholder="Save custom DSP preset name (e.g. Gym Workout Hard-Cut)..."
            value={newPresetName}
            onChange={(e) => setNewPresetName(e.target.value)}
            className="flex-1 rounded-lg border border-white/10 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
          />
          <input
            type="text"
            placeholder="Optional notes..."
            value={newPresetDesc}
            onChange={(e) => setNewPresetDesc(e.target.value)}
            className="flex-1 rounded-lg border border-white/10 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
          />
          <button
            type="submit"
            disabled={isSaving || !newPresetName.trim()}
            className="flex items-center justify-center gap-1.5 rounded-lg bg-cyan-500 px-4 py-1.5 text-xs font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:opacity-50"
          >
            <Save className="h-3.5 w-3.5" />
            <span>{isSaving ? "Saving..." : "Save Preset to DB"}</span>
          </button>
        </form>
      </div>
    </div>
  );
}
