"use client";

import React, { useMemo, useState } from "react";
import {
  FlaskConical,
  PlayCircle,
  PlusCircle,
  Sparkles,
  AlertTriangle,
  CheckCircle,
  ArrowRight,
} from "lucide-react";
import { DspEngineConfig, TrackItem } from "@/lib/automix-types";
import { planAutoMixTransition } from "@/lib/automix-planner";
import { TransitionEvaluationRecord } from "@/db/schema";

interface TransitionMatrixLabProps {
  tracks: TrackItem[];
  config: DspEngineConfig;
  evaluations: TransitionEvaluationRecord[];
  onAuditionPair: (fromTrackId: string | number, toTrackId: string | number) => void;
  onLogEvaluation: (payload: {
    fromTrackTitle: string;
    toTrackTitle: string;
    isNonCuratedPair: boolean;
    fromBpm: number;
    toBpm: number;
    fromCamelot: string;
    toCamelot: string;
    strategyUsed: string;
    stretchRatioPct: number;
    mixDurationSec: number;
    cueOutSec: number;
    cueInSec: number;
    androidAutoMixScore: number;
    appleBaselineScore: number;
    crossfadeBaselineScore: number;
    notes: string;
  }) => Promise<void>;
}

export function TransitionMatrixLab({
  tracks,
  config,
  evaluations,
  onAuditionPair,
  onLogEvaluation,
}: TransitionMatrixLabProps) {
  const [fromIdx, setFromIdx] = useState(0);
  const [toIdx, setToIdx] = useState(1);
  const [notes, setNotes] = useState("");
  const [scoreOverride, setScoreOverride] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const safeFromIdx = tracks[fromIdx] ? fromIdx : 0;
  const safeToIdx = tracks[toIdx] ? toIdx : Math.min(1, tracks.length - 1);

  const trackA = tracks[safeFromIdx];
  const trackB = tracks[safeToIdx];

  const plan = useMemo(() => {
    if (!trackA || !trackB) return null;
    return planAutoMixTransition(trackA, trackB, config);
  }, [trackA, trackB, config]);

  if (!trackA || !trackB || !plan) return null;

  const isNonCuratedPair = !trackA.isCurated || !trackB.isCurated;
  const effectiveAndroidScore = scoreOverride ?? plan.androidAutoMixScore;

  const quickScenarios = [
    {
      label: "1. Curated Club Parity (124→126)",
      tag: "DJ Beatmatch",
      aSlug: "velvet-horizon",
      bSlug: "obsidian-pulse",
    },
    {
      label: "2. Non-Curated Vocal Clash",
      tag: "Vocal Mid-Scoop",
      aSlug: "obsidian-pulse",
      bSlug: "midnight-polaroid",
    },
    {
      label: "3. Live Applause / Silence Tail",
      tag: "Zero-Dead-Air Cut",
      aSlug: "fluorescent-youth-live",
      bSlug: "neon-raindrops-808",
    },
    {
      label: "4. 72→144 BPM Half/Double Lock",
      tag: "2x Grid Lock",
      aSlug: "neon-raindrops-808",
      bSlug: "subsurface-2step",
    },
    {
      label: "5. Δ28 BPM + Key Clash Rescue",
      tag: "Dub Echo Freeze",
      aSlug: "subsurface-2step",
      bSlug: "solaris-boogie",
    },
  ];

  const selectBySlugs = (aSlug: string, bSlug: string) => {
    const idxA = tracks.findIndex((t) => t.slug === aSlug);
    const idxB = tracks.findIndex((t) => t.slug === bSlug);
    if (idxA >= 0 && idxB >= 0) {
      setFromIdx(idxA);
      setToIdx(idxB);
      setScoreOverride(null);
    }
  };

  const handleLog = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await onLogEvaluation({
        fromTrackTitle: trackA.title,
        toTrackTitle: trackB.title,
        isNonCuratedPair,
        fromBpm: trackA.bpm,
        toBpm: trackB.bpm,
        fromCamelot: trackA.camelotKey,
        toCamelot: trackB.camelotKey,
        strategyUsed: plan.strategy,
        stretchRatioPct: plan.stretchPctA,
        mixDurationSec: plan.mixDurationSec,
        cueOutSec: plan.cueOutSec,
        cueInSec: plan.cueInSec,
        androidAutoMixScore: effectiveAndroidScore,
        appleBaselineScore: plan.appleBaselineScore,
        crossfadeBaselineScore: plan.crossfadeBaselineScore,
        notes:
          notes.trim() ||
          `${plan.strategyLabel} (${plan.tempoRatioMode}, ${plan.harmonicRelation})`,
      });
      setNotes("");
      setScoreOverride(null);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Torture-Test Scenario Presets & Arbitrary Pair Solver */}
      <div className="rounded-2xl border border-white/10 bg-[#0d1322]/90 p-5 shadow-xl">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <FlaskConical className="h-4 w-4 text-cyan-400" />
              <h3 className="text-sm font-bold tracking-wide text-white uppercase">
                Curated & Non-Curated Torture-Test Solver Lab
              </h3>
            </div>
            <p className="mt-0.5 text-xs text-slate-400">
              Test edge cases where server-curated AutoMix struggles: vocal outros, 2:1 poly-tempo jumps, live applause tails, and local MP3s
            </p>
          </div>
          <span
            className={`rounded-full px-3 py-1 text-xs font-bold ${
              isNonCuratedPair
                ? "bg-amber-500/20 text-amber-300 ring-1 ring-amber-400/30"
                : "bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/30"
            }`}
          >
            {isNonCuratedPair ? "NON-CURATED PAIR ACTIVE" : "CURATED CATALOG PAIR"}
          </span>
        </div>

        {/* Scenario Quick Buttons */}
        <div className="mb-4 flex flex-wrap gap-2">
          {quickScenarios.map((sc) => (
            <button
              key={sc.label}
              type="button"
              onClick={() => selectBySlugs(sc.aSlug, sc.bSlug)}
              className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-slate-900/90 px-3 py-1.5 text-xs text-slate-200 transition hover:border-cyan-400/50 hover:bg-cyan-500/15"
            >
              <span className="font-medium">{sc.label}</span>
              <span className="rounded bg-cyan-500/20 px-1.5 py-0.5 font-mono text-[10px] text-cyan-300">
                {sc.tag}
              </span>
            </button>
          ))}
        </div>

        {/* Pair Dropdowns */}
        <div className="grid gap-3 md:grid-cols-[1fr_auto_1fr]">
          <div className="rounded-xl border border-white/10 bg-slate-950/80 p-3">
            <label className="mb-1 block text-[11px] font-semibold tracking-wider text-cyan-300 uppercase">
              Outgoing Deck A Track
            </label>
            <select
              value={safeFromIdx}
              onChange={(e) => {
                setFromIdx(Number(e.target.value));
                setScoreOverride(null);
              }}
              className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-xs font-medium text-white focus:border-cyan-400 focus:outline-none"
            >
              {tracks.map((t, i) => (
                <option key={t.id} value={i}>
                  {t.isCurated ? "[Curated]" : "[Non-Curated]"} {t.title} — {t.bpm} BPM ({t.camelotKey})
                </option>
              ))}
            </select>
            <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-slate-400">
              <span>Key: {trackA.musicalKey}</span>
              <span>• Vocal Outro: {Math.round(trackA.vocalOutroDensity * 100)}%</span>
              <span>
                • Silence Tail: {trackA.hasSilenceTail ? "Yes (RMS Gate)" : "Clean"}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-center">
            <div className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-slate-900 text-cyan-400">
              <ArrowRight className="h-4 w-4" />
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-slate-950/80 p-3">
            <label className="mb-1 block text-[11px] font-semibold tracking-wider text-fuchsia-300 uppercase">
              Incoming Deck B Track
            </label>
            <select
              value={safeToIdx}
              onChange={(e) => {
                setToIdx(Number(e.target.value));
                setScoreOverride(null);
              }}
              className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-xs font-medium text-white focus:border-fuchsia-400 focus:outline-none"
            >
              {tracks.map((t, i) => (
                <option key={t.id} value={i}>
                  {t.isCurated ? "[Curated]" : "[Non-Curated]"} {t.title} — {t.bpm} BPM ({t.camelotKey})
                </option>
              ))}
            </select>
            <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-slate-400">
              <span>Key: {trackB.musicalKey}</span>
              <span>• Vocal Intro: {Math.round(trackB.vocalIntroDensity * 100)}%</span>
              <span>• Intro Drop: {trackB.introEndSec}s</span>
            </div>
          </div>
        </div>

        {/* Computed Plan Diagnostic Cards + Score Comparison */}
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          <div className="rounded-xl border border-white/10 bg-slate-950/75 p-4">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-bold tracking-wider text-slate-300 uppercase">
                Solver Synthesis & Cue Matrix
              </span>
              <span className="rounded-md bg-cyan-500/20 px-2 py-0.5 font-mono text-xs font-bold text-cyan-300">
                {plan.strategy}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div className="rounded-lg bg-slate-900/90 p-2.5">
                <div className="text-[10px] text-slate-400">Tempo Grid Mode</div>
                <div className="mt-0.5 font-semibold text-white">{plan.tempoRatioMode}</div>
              </div>
              <div className="rounded-lg bg-slate-900/90 p-2.5">
                <div className="text-[10px] text-slate-400">WSOLA Stretch Ramp</div>
                <div className="mt-0.5 font-mono font-semibold text-cyan-300">
                  {plan.stretchPctA >= 0 ? "+" : ""}
                  {plan.stretchPctA}% ({plan.mixBars} bars / {plan.mixDurationSec}s)
                </div>
              </div>
              <div className="rounded-lg bg-slate-900/90 p-2.5">
                <div className="text-[10px] text-slate-400">Sweet-Spot Cues</div>
                <div className="mt-0.5 font-mono font-semibold text-white">
                  Out {plan.cueOutSec}s → In {plan.cueInSec}s
                </div>
              </div>
              <div className="rounded-lg bg-slate-900/90 p-2.5">
                <div className="text-[10px] text-slate-400">Vocal / EQ Action</div>
                <div className="mt-0.5 font-mono font-semibold text-amber-300">
                  Mid {plan.vocalMidScoopDb}dB • Swap @ 50%
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onAuditionPair(trackA.id, trackB.id)}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5 text-xs font-bold text-white shadow-lg shadow-cyan-500/20 transition hover:brightness-110"
            >
              <PlayCircle className="h-4 w-4" />
              <span>Load Pair & Audition Transition in Player Now (T-3s)</span>
            </button>
          </div>

          {/* 3-Way Comparative Seamlessness Score */}
          <div className="flex flex-col justify-between rounded-xl border border-white/10 bg-slate-950/75 p-4">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-bold tracking-wider text-slate-300 uppercase">
                Seamlessness Benchmark (Curated & Non-Curated)
              </span>
              {isNonCuratedPair && (
                <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-300">
                  <Sparkles className="h-3.5 w-3.5" /> +
                  {effectiveAndroidScore - plan.appleBaselineScore} pts vs Catalog-Only
                </span>
              )}
            </div>

            <div className="space-y-3">
              <div>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="font-semibold text-cyan-200">
                    Android PulseMix On-Device Engine (Ours)
                  </span>
                  <span className="font-mono font-bold text-cyan-300">
                    {effectiveAndroidScore} / 100
                  </span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
                  <div
                    style={{ width: `${effectiveAndroidScore}%` }}
                    className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-emerald-400"
                  />
                </div>
              </div>

              <div>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="text-slate-300">
                    Apple Music iOS 26 AutoMix (Catalog Baseline)
                  </span>
                  <span className="font-mono font-semibold text-slate-200">
                    {plan.appleBaselineScore} / 100
                  </span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
                  <div
                    style={{ width: `${plan.appleBaselineScore}%` }}
                    className="h-full rounded-full bg-indigo-400"
                  />
                </div>
              </div>

              <div>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="text-slate-400">Standard 6s Linear Crossfade</span>
                  <span className="font-mono text-slate-400">
                    {plan.crossfadeBaselineScore} / 100
                  </span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
                  <div
                    style={{ width: `${plan.crossfadeBaselineScore}%` }}
                    className="h-full rounded-full bg-rose-500/75"
                  />
                </div>
              </div>
            </div>

            <div className="mt-3 flex items-center gap-2 rounded-lg bg-slate-900/90 px-3 py-2 text-[11px] text-slate-300">
              {isNonCuratedPair ? (
                <>
                  <AlertTriangle className="h-4 w-4 shrink-0 text-amber-400" />
                  <span>
                    Catalog-only AutoMix drops to <strong>{plan.appleBaselineScore}</strong> on
                    non-curated/local pairs; our on-device LiteRT + DSP rescue holds{" "}
                    <strong className="text-emerald-300">{effectiveAndroidScore}</strong>.
                  </span>
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4 shrink-0 text-emerald-400" />
                  <span>
                    Full DJ-level parity achieved on curated harmonic club tracks with zero server
                    dependency.
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Log Evaluation Run Form */}
        <form
          onSubmit={handleLog}
          className="mt-4 flex flex-col gap-2.5 rounded-xl border border-white/10 bg-slate-950/60 p-3 sm:flex-row sm:items-center"
        >
          <div className="flex items-center gap-2">
            <label className="text-xs whitespace-nowrap text-slate-300">
              QA Score:
            </label>
            <input
              type="number"
              min={50}
              max={100}
              value={effectiveAndroidScore}
              onChange={(e) => setScoreOverride(Number(e.target.value))}
              className="w-16 rounded-lg border border-white/10 bg-slate-900 px-2 py-1.5 font-mono text-xs text-cyan-300"
            />
          </div>
          <input
            type="text"
            placeholder="Add engineer QA listening note for this transition pair..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="flex-1 rounded-lg border border-white/10 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-cyan-400 focus:outline-none"
          />
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex items-center justify-center gap-1.5 rounded-lg bg-emerald-500 px-4 py-1.5 text-xs font-bold text-slate-950 transition hover:bg-emerald-400 disabled:opacity-50"
          >
            <PlusCircle className="h-3.5 w-3.5" />
            <span>{isSubmitting ? "Logging..." : "Log Evaluation to DB"}</span>
          </button>
        </form>
      </div>

      {/* Persisted PostgreSQL Transition Evaluation Log */}
      <div className="rounded-2xl border border-white/10 bg-[#0d1322]/90 p-5 shadow-xl">
        <h4 className="mb-3 text-xs font-bold tracking-wider text-slate-300 uppercase">
          PostgreSQL Transition QA Telemetry Log ({evaluations.length} Runs)
        </h4>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-[11px] text-slate-400">
                <th className="py-2 pr-3">Transition Pair</th>
                <th className="py-2 px-3">Type</th>
                <th className="py-2 px-3">BPM / Key</th>
                <th className="py-2 px-3">Selected Strategy</th>
                <th className="py-2 px-3 text-right">PulseMix</th>
                <th className="py-2 px-3 text-right">Catalog Base</th>
                <th className="py-2 pl-3">QA Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {evaluations.map((ev) => (
                <tr key={ev.id} className="hover:bg-white/[0.02]">
                  <td className="py-2.5 pr-3 font-medium text-white">
                    {ev.fromTrackTitle} → {ev.toTrackTitle}
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                        ev.isNonCuratedPair
                          ? "bg-amber-500/20 text-amber-300"
                          : "bg-emerald-500/20 text-emerald-300"
                      }`}
                    >
                      {ev.isNonCuratedPair ? "Non-Curated" : "Curated"}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-mono text-[11px] text-slate-300">
                    {ev.fromBpm}→{ev.toBpm} ({ev.fromCamelot}→{ev.toCamelot})
                  </td>
                  <td className="py-2.5 px-3 font-mono text-[11px] text-cyan-300">
                    {ev.strategyUsed}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-300">
                    {ev.androidAutoMixScore}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-400">
                    {ev.appleBaselineScore}
                  </td>
                  <td className="max-w-xs truncate py-2.5 pl-3 text-slate-400" title={ev.notes}>
                    {ev.notes}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
