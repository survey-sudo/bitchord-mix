"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  Activity,
  FlaskConical,
  Cpu,
  Sparkles,
  Zap,
  CheckCircle2,
  Headphones,
} from "lucide-react";
import {
  DspEngineConfig,
  LiveMixTelemetry,
  TrackItem,
} from "@/lib/automix-types";
import {
  DeviceBenchmarkRecord,
  TransitionEvaluationRecord,
} from "@/db/schema";
import { AutoMixWebAudioEngine } from "@/lib/automix-audio-engine";
import { analyzeAudioBufferOnDevice } from "@/lib/audio-analyzer";
import { planAutoMixTransition } from "@/lib/automix-planner";
import { AndroidPlayerMockup } from "./AndroidPlayerMockup";
import { DualDeckVisualizer } from "./DualDeckVisualizer";
import { TransitionMatrixLab } from "./TransitionMatrixLab";
import { ArchitectureBlueprintTab } from "./ArchitectureBlueprintTab";

interface AutoMixStudioClientProps {
  initialTracks: TrackItem[];
  initialPresets: DspEngineConfig[];
  initialEvaluations: TransitionEvaluationRecord[];
  initialBenchmarks: DeviceBenchmarkRecord[];
}

type StudioTab = "live-dsp" | "non-curated-lab" | "android-blueprint";

const UPLOAD_GRADIENTS = [
  "from-cyan-500 via-teal-600 to-slate-900",
  "from-fuchsia-500 via-rose-600 to-indigo-950",
  "from-amber-400 via-orange-600 to-slate-950",
  "from-emerald-400 via-cyan-700 to-zinc-950",
];

export function AutoMixStudioClient({
  initialTracks,
  initialPresets,
  initialEvaluations,
  initialBenchmarks,
}: AutoMixStudioClientProps) {
  const [queue, setQueue] = useState<TrackItem[]>(initialTracks);
  const [presets, setPresets] = useState<DspEngineConfig[]>(initialPresets);
  const [config, setConfig] = useState<DspEngineConfig>(
    initialPresets[0] ?? {
      name: "PulseMix Club DJ (Recommended)",
      description: "Default on-device AutoMix configuration",
      maxStretchPct: 10.0,
      defaultMixBars: 8,
      bassSwapSharpness: 0.84,
      vocalDuckDb: -9.5,
      harmonicWeight: 0.75,
      enableHalfDoubleLock: true,
      enableEchoFreezeFallback: true,
      silenceGateDb: -42.0,
      npuDelegate: "AUTO_NNAPI_GPU",
      isBuiltIn: true,
    }
  );
  const [evaluations, setEvaluations] =
    useState<TransitionEvaluationRecord[]>(initialEvaluations);
  const [benchmarks, setBenchmarks] =
    useState<DeviceBenchmarkRecord[]>(initialBenchmarks);

  const [activeTab, setActiveTab] = useState<StudioTab>("live-dsp");
  const [isAnalyzingUpload, setIsAnalyzingUpload] = useState(false);
  const [uploadNotice, setUploadNotice] = useState<string | null>(null);

  const initialPlan =
    initialTracks.length >= 2
      ? planAutoMixTransition(initialTracks[0], initialTracks[1], config)
      : null;

  const [telemetry, setTelemetry] = useState<LiveMixTelemetry>({
    isPlaying: false,
    isMixing: false,
    autoMixEnabled: true,
    mixProgress: 0,
    activeTrackIndex: 0,
    nextTrackIndex: initialTracks.length > 1 ? 1 : 0,
    deckAPositionSec: 0,
    deckBPositionSec: initialPlan?.cueInSec ?? 0,
    deckADurationSec: initialTracks[0]?.durationSec ?? 38,
    deckBDurationSec: initialTracks[1]?.durationSec ?? 38,
    deckACurrentBpm: initialTracks[0]?.bpm ?? 124,
    deckBCurrentBpm: initialTracks[1]?.bpm ?? 126,
    deckARate: 1.0,
    deckBRate: 1.0,
    deckAGain: 1.0,
    deckBGain: 0.0,
    deckALowDb: 0,
    deckBLowDb: -24,
    deckAMidDb: 0,
    deckBMidDb: 0,
    deckAHpfHz: 22,
    echoWetMix: 0,
    beatPhase: 0,
    barBeatIndex: 0,
    activePlan: initialPlan,
  });

  const engineRef = useRef<AutoMixWebAudioEngine | null>(null);

  useEffect(() => {
    const engine = new AutoMixWebAudioEngine(config);
    engine.setTelemetryListener((snap) => {
      setTelemetry(snap);
    });
    engine.setQueue(initialTracks, false);
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleChangeConfig = (next: DspEngineConfig) => {
    setConfig(next);
    engineRef.current?.updateConfig(next);
  };

  const handleSelectPreset = (preset: DspEngineConfig) => {
    setConfig(preset);
    engineRef.current?.updateConfig(preset);
  };

  const handleSavePreset = async (name: string, description: string) => {
    const res = await fetch("/api/presets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...config,
        name,
        description,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      setPresets((prev) => [...prev, data.preset]);
      setConfig(data.preset);
    }
  };

  const handleDeletePreset = async (id: number) => {
    const res = await fetch(`/api/presets?id=${id}`, { method: "DELETE" });
    if (res.ok) {
      setPresets((prev) => prev.filter((p) => p.id !== id));
    }
  };

  const handleUploadFiles = async (files: FileList) => {
    if (!engineRef.current || files.length === 0) return;
    setIsAnalyzingUpload(true);
    setUploadNotice(null);

    try {
      const newlyAdded: TrackItem[] = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const buffer = await engineRef.current.decodeFileToBuffer(file);
        const features = analyzeAudioBufferOnDevice(buffer);
        const cleanTitle = file.name.replace(/\.[^/.]+$/, "");
        const coverGradient =
          UPLOAD_GRADIENTS[(queue.length + i) % UPLOAD_GRADIENTS.length];

        // Persist extracted on-device features in PostgreSQL
        const res = await fetch("/api/tracks", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: cleanTitle,
            artist: "Local Device Upload",
            genre: "Uncurated Local Audio",
            bpm: features.bpm,
            camelotKey: features.camelotKey,
            musicalKey: features.musicalKey,
            durationSec: features.durationSec,
            introEndSec: features.introEndSec,
            outroStartSec: features.outroStartSec,
            vocalOutroDensity: features.vocalOutroDensity,
            vocalIntroDensity: features.vocalIntroDensity,
            energy: features.energy,
            hasSilenceTail: features.hasSilenceTail,
            coverGradient,
          }),
        });

        let trackId: string | number = `local-${Date.now()}-${i}`;
        let slug = `local-${Date.now()}-${i}`;
        if (res.ok) {
          const saved = await res.json();
          trackId = saved.track.id;
          slug = saved.track.slug;
        }

        engineRef.current.registerDecodedBuffer(
          trackId,
          buffer,
          features.waveformPeaks
        );

        newlyAdded.push({
          id: trackId,
          slug,
          title: cleanTitle,
          artist: "Local Device Upload",
          genre: "Uncurated Local Audio",
          bpm: features.bpm,
          camelotKey: features.camelotKey,
          musicalKey: features.musicalKey,
          durationSec: features.durationSec,
          isCurated: false,
          introEndSec: features.introEndSec,
          outroStartSec: features.outroStartSec,
          vocalOutroDensity: features.vocalOutroDensity,
          vocalIntroDensity: features.vocalIntroDensity,
          energy: features.energy,
          hasSilenceTail: features.hasSilenceTail,
          synthPreset: "local_pcm",
          coverGradient,
          isLocalUpload: true,
          waveformPeaks: features.waveformPeaks,
        });
      }

      if (newlyAdded.length > 0) {
        const insertPos = telemetry.activeTrackIndex + 1;
        const nextQueue = [
          ...queue.slice(0, insertPos),
          ...newlyAdded,
          ...queue.slice(insertPos),
        ];
        setQueue(nextQueue);
        engineRef.current.setQueue(nextQueue, true);

        const first = newlyAdded[0];
        setUploadNotice(
          `On-Device Analysis Ready: "${first.title}" → ${first.bpm} BPM • ${first.camelotKey} (${first.musicalKey}) queued next! Click "Audition Mix (T-3s)" to blend into it.`
        );
      }
    } catch (err) {
      console.error("Failed to decode uploaded audio:", err);
      setUploadNotice(
        "Could not decode audio format. Try a standard MP3, WAV, FLAC, M4A, or OGG file."
      );
    } finally {
      setIsAnalyzingUpload(false);
    }
  };

  const handleAuditionPair = (
    fromTrackId: string | number,
    toTrackId: string | number
  ) => {
    if (!engineRef.current) return;
    const fromTrack = queue.find((t) => t.id === fromTrackId);
    const toTrack = queue.find((t) => t.id === toTrackId);
    if (!fromTrack || !toTrack) return;

    // Place fromTrack followed immediately by toTrack at the front of the active mix pair
    const remaining = queue.filter(
      (t) => t.id !== fromTrackId && t.id !== toTrackId
    );
    const reordered =
      fromTrackId === toTrackId
        ? queue
        : [fromTrack, toTrack, ...remaining];

    setQueue(reordered);
    engineRef.current.setAutoMixEnabled(true);
    engineRef.current.setQueue(reordered, false);
    engineRef.current.playTrackAtIndex(0, 0);
    engineRef.current.triggerSweetSpotPreview();
  };

  const handleLogEvaluation = async (payload: {
    fromTrackTitle: string;
    toTrackTitle: string;
    isNonCuratedPair: boolean;
    fromBpm: number;
    toBpm: number;
    fromCamelot: string;
    toCamelot: string;
    strategyUsed: string;
    stretchRatioPct: number;
    mixDurationSec: number;
    cueOutSec: number;
    cueInSec: number;
    androidAutoMixScore: number;
    appleBaselineScore: number;
    crossfadeBaselineScore: number;
    notes: string;
  }) => {
    const res = await fetch("/api/evaluations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      const data = await res.json();
      setEvaluations((prev) => [data.evaluation, ...prev]);
    }
  };

  const handleAddBenchmark = async (payload: {
    deviceName: string;
    socTier: string;
    delegateUsed: string;
    decode30sMs: number;
    modelInferenceMs: number;
    dspCpuLoadPct: number;
    peakRamMb: number;
    batteryDrainPctPerHr: number;
    nonCuratedPassRatePct: number;
  }) => {
    const res = await fetch("/api/benchmarks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      const data = await res.json();
      setBenchmarks((prev) =>
        [...prev, data.benchmark].sort(
          (a, b) => a.modelInferenceMs - b.modelInferenceMs
        )
      );
    }
  };

  const trackA = queue[telemetry.activeTrackIndex] ?? queue[0];
  const trackB = queue[telemetry.nextTrackIndex] ?? queue[1] ?? queue[0];
  const peaksA =
    trackA && engineRef.current
      ? engineRef.current.getWaveformPeaks(trackA)
      : new Array(120).fill(0.5);
  const peaksB =
    trackB && engineRef.current
      ? engineRef.current.getWaveformPeaks(trackB)
      : new Array(120).fill(0.5);

  return (
    <div className="min-h-screen bg-[#07090e] pb-14">
      {/* Top Studio Engineering Header */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#07090e]/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 via-sky-500 to-indigo-600 text-slate-950 shadow-lg shadow-cyan-500/20">
              <Headphones className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-extrabold tracking-tight text-white sm:text-lg">
                  PulseMix Android AutoMix Engine
                </h1>
                <span className="rounded-full border border-cyan-400/30 bg-cyan-500/15 px-2.5 py-0.5 font-mono text-[10px] font-bold text-cyan-300">
                  v2.4 ON-DEVICE NPU + DSP
                </span>
              </div>
              <p className="text-xs text-slate-400">
                DJ-grade parity with Apple Music AutoMix on curated tracks • Superior 5-mode
                on-device rescue on non-curated & local audio
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <div className="hidden items-center gap-4 rounded-xl border border-white/10 bg-slate-900/75 px-3.5 py-1.5 text-xs xl:flex">
              <span className="flex items-center gap-1.5 text-slate-300">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                LiteRT <strong>3.74 MB INT8</strong>
              </span>
              <span className="text-white/15">|</span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
                <strong>12ms</strong> NPU Inference
              </span>
              <span className="text-white/15">|</span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <strong>94.8%</strong> Non-Curated Pass
              </span>
            </div>

            <button
              type="button"
              onClick={() => engineRef.current?.triggerSweetSpotPreview()}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-400 px-4 py-2 text-xs font-bold text-slate-950 shadow-lg shadow-cyan-500/25 transition hover:brightness-110 active:scale-95"
            >
              <Zap className="h-3.5 w-3.5" />
              <span>Hear Live DJ AutoMix Now</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Responsive Two-Column Studio Workspace */}
      <main className="mx-auto mt-6 grid max-w-[1440px] gap-6 px-4 sm:px-6 lg:grid-cols-[415px_1fr]">
        {/* Left Sticky Column: Flagship Android Player Simulator */}
        <aside className="lg:sticky lg:top-20 lg:self-start">
          <AndroidPlayerMockup
            queue={queue}
            telemetry={telemetry}
            config={config}
            isAnalyzingUpload={isAnalyzingUpload}
            uploadNotice={uploadNotice}
            onTogglePlay={() => engineRef.current?.togglePlayPause()}
            onSkipPrev={() => engineRef.current?.skipPrev()}
            onSkipNext={() => engineRef.current?.skipNext()}
            onSeek={(sec) => engineRef.current?.seekDeckA(sec)}
            onTriggerSweetSpot={() => engineRef.current?.triggerSweetSpotPreview()}
            onToggleAutoMix={(enabled) =>
              engineRef.current?.setAutoMixEnabled(enabled)
            }
            onSelectTrackIndex={(idx) =>
              engineRef.current?.playTrackAtIndex(idx, 0)
            }
            onUploadFiles={handleUploadFiles}
          />
        </aside>

        {/* Right Engineering Workbench Column */}
        <section className="min-w-0 space-y-5">
          {/* Primary Navigation Tabs */}
          <div className="grid grid-cols-1 gap-2 rounded-2xl border border-white/10 bg-[#0d1322]/90 p-1.5 sm:grid-cols-3">
            <button
              type="button"
              onClick={() => setActiveTab("live-dsp")}
              className={`flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold transition ${
                activeTab === "live-dsp"
                  ? "bg-gradient-to-r from-cyan-500/25 to-blue-600/25 text-white ring-1 ring-cyan-400/50"
                  : "text-slate-400 hover:bg-white/[0.03] hover:text-slate-200"
              }`}
            >
              <Activity className="h-4 w-4 text-cyan-400" />
              <span>Live Dual-Deck DSP & Tuning</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("non-curated-lab")}
              className={`flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold transition ${
                activeTab === "non-curated-lab"
                  ? "bg-gradient-to-r from-cyan-500/25 to-blue-600/25 text-white ring-1 ring-cyan-400/50"
                  : "text-slate-400 hover:bg-white/[0.03] hover:text-slate-200"
              }`}
            >
              <FlaskConical className="h-4 w-4 text-amber-400" />
              <span>Non-Curated Solver Lab & QA</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("android-blueprint")}
              className={`flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold transition ${
                activeTab === "android-blueprint"
                  ? "bg-gradient-to-r from-cyan-500/25 to-blue-600/25 text-white ring-1 ring-cyan-400/50"
                  : "text-slate-400 hover:bg-white/[0.03] hover:text-slate-200"
              }`}
            >
              <Cpu className="h-4 w-4 text-emerald-400" />
              <span>Android ML Blueprint, Code & NPU</span>
            </button>
          </div>

          {/* Active Workbench View */}
          {activeTab === "live-dsp" && (
            <DualDeckVisualizer
              trackA={trackA}
              trackB={trackB}
              peaksA={peaksA}
              peaksB={peaksB}
              telemetry={telemetry}
              config={config}
              presets={presets}
              onChangeConfig={handleChangeConfig}
              onSelectPreset={handleSelectPreset}
              onSavePreset={handleSavePreset}
              onDeletePreset={handleDeletePreset}
            />
          )}

          {activeTab === "non-curated-lab" && (
            <TransitionMatrixLab
              tracks={queue}
              config={config}
              evaluations={evaluations}
              onAuditionPair={handleAuditionPair}
              onLogEvaluation={handleLogEvaluation}
            />
          )}

          {activeTab === "android-blueprint" && (
            <ArchitectureBlueprintTab
              benchmarks={benchmarks}
              onAddBenchmark={handleAddBenchmark}
            />
          )}
        </section>
      </main>
    </div>
  );
}
